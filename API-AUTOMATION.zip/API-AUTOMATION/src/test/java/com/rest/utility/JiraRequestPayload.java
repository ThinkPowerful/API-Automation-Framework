package com.rest.utility;

public class JiraRequestPayload {
	
	public static String createIssue;
	
	public static String createIssue(String parentKey, String summary, String description)
	{
		JiraRequestPayload.createIssue="{\"fields\":{\"project\":{\"key\": \"ECMCON\"},\"parent\":{\"key\": \""+parentKey+"\"},\"summary\": \""+summary+" \",\"description\": \""+description+"\",\"issuetype\":{\"name\": \"Bug Sub-Task\"}}}";
		return createIssue;
	}
	
}
