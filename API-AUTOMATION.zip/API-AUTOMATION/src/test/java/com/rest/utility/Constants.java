package com.rest.utility;
/**
 * @author Naveen Chenjigaram
 *
 * 
 */
public interface Constants {
	public String INTERNET_ST_URL = "http://mwr-st.nl.eu.abnamro.com:9200/eps";
	public String INTERNET_ET_URL = "http://mwr-et1.nl.eu.abnamro.com:8100/eps";
	public String INTRANET_ST_URL = "http://isssiast-ao.nl.eu.abnamro.com/toegang/p1.asp";
	public String INTRANET_ET_URL = "http://isssiaet.ao.nl.abnamro.com/toegang/p1.asp";
}
