package com.rest.searchservice.searchdocuments.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rest.utility.DataUtil;
import com.rest.utility.Xls_Reader;

public class RelatedEntityInfoTest {
	
		String sheetName="CDP_ValidationForContNumTest";
			
			@BeforeClass
			public void launchApplication() 
			{
				try {
					
				} catch (Exception e) {
					
				}
			}
			
			@Test(dataProvider="getData")
			public void validationForContractNumTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
			{
				
			}
			
			@DataProvider(name="getData")
			public Object[][] getData() 
			{
				return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\ServicesTestData.xlsx"), sheetName);
			}
			
			@AfterClass(alwaysRun=true)
			public void tearDown() throws IOException
			{
				
			}


	}



