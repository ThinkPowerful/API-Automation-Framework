package com.rest.documentservice.updateDocument.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rest.base.test.BaseTest;
import com.rest.documentservice.UpdateDocument;
import com.rest.utility.DataUtil;
import com.rest.utility.Xls_Reader;

import io.restassured.response.Response;

public class ItemNotFoundTest extends BaseTest{
	
	String sheetName = "ItemNotFoundTest";
	UpdateDocument updateDocument;
	JSONObject jsonObject;
	JSONObject errorObject;
	JSONArray errorsArray;
	
	@BeforeClass
	public void initiateTestName() {
		try {
			init(testScenarioName.get("TS91"), authorName.get("TS91"), moduleName.get("TS91"));
			this.updateDocument = new UpdateDocument();
			
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
			throw new SkipException("Skipping Test: @BeforeClass configuration failed");
		}
	}
	
	@Test(dataProvider = "getData")
	public void verifyItemNotFoundTest(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException {

		try {
			Response response = updateDocument.updateDocumentWithAllParameters(data.get("Document ID"),
					data.get("Source ID"), data.get("Title"), data.get("Description"), data.get("Source Label"),
					data.get("Access Type"), data.get("Security Level"), data.get("Document Name"), data.get("Source"),
					data.get("Status"), data.get("Related entity"), data.get("Scope Info"), data.get("Actions list"),
					data.get("Retention Period"), data.get("Availability Rating"), data.get("Legal hold status"),
					data.get("Document Type"), data.get("Scan status"), data.get("Validity Status"),
					data.get("Content size"), data.get("Content type"), data.get("Document Validity Status"),
					data.get("Annotation Info Available"), data.get("Valid From Date"), data.get("Valid To Date"),
					data.get("Event Date"), data.get("Version Label"), data.get("Additional Attribute"),
					data.get("Authors"));
			String responseBody = updateDocument.getPrettifiedResponseBody(response);
			JSONObject jsonObject = new JSONObject(responseBody);
			this.errorsArray = jsonObject.getJSONArray("errors");
			this.errorObject = errorsArray.getJSONObject(0);
			String message = errorObject.getString("message");
			String status = String.valueOf(errorObject.getInt("status"));
			String code = errorObject.getString("code");
			if (message.equals(data.get("Expected Message")) &&  code.equals(data.get("Expected Code")) &&  status.equals(data.get("Expected Status Code"))) 
				{
				test.get(0).info("Test Data Set: "+data.entrySet().toString());
				test.get(0).pass("Response message, status ,code matches as expected"+", Response Body " + updateDocument.extentReportFormatter(responseBody));
				Assert.assertTrue(true);
			} else {
				test.get(0).info("Test Data Set: "+data.entrySet().toString());
				test.get(0).fail("Response message, status ,code does not matches as expected"+", Response Body " + updateDocument.extentReportFormatter(responseBody));
				//getDocumentWithContent.createBugInJira("Failed: "+data.get("FailureTitleInJira")+DocumentIDMissingTest.class.getName(), data.entrySet().toString());
				Assert.fail();
			}
		} catch (Exception e) {
			test.get(0).skip("Skipping This test due to exception: " + e);
			Assert.fail();
		}

	}

	@DataProvider(name = "getData")
	public Object[][] getData() {
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(
				System.getProperty("user.dir") + "/ExcelFiles/"+prop.getProperty("ENVIRNOMENT")+"/TestData/DocumentService/UpdateDocumentTestData.xlsx"),
				sheetName);
	}

}
