package com.rest.documentservice.updateLifecycleStatus.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rest.base.test.BaseTest;
import com.rest.documentservice.ImportDocument;
import com.rest.documentservice.UpdateLifecycleStatus;
import com.rest.dossierservice.CreateDossier;
import com.rest.utility.DataUtil;
import com.rest.utility.Xls_Reader;

import io.restassured.response.Response;

public class IlLeagalDocumentStatusTest extends BaseTest{

	String sheetName = "IlLeagalDocumentStatusTest";
	UpdateLifecycleStatus updateLifecycleStatus;
	ImportDocument importDocument;
	CreateDossier createDossier;
	JSONObject jsonObject;
	String documentId;
	String dossierId;

	@BeforeClass
	public void initiateTestName() {
		try {
			init(testScenarioName.get("TS71"), authorName.get("TS71"), moduleName.get("TS71"));
			this.updateLifecycleStatus = new UpdateLifecycleStatus();
			this.importDocument = new ImportDocument();
			this.createDossier = new CreateDossier();
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
			throw new SkipException("Skipping Test: @BeforeClass configuration failed");
		}
	}

	@BeforeMethod
	public void preReqCreateDOssierAndImportDocument() {
		try {
			Response response;
			String responseBody;
			response = createDossier.createDossier("Rest_1724_28022019");
			responseBody = createDossier.getPrettifiedResponseBody(response);
			this.jsonObject = new JSONObject(responseBody);
			this.dossierId = jsonObject.getString("dossierId");
			response = importDocument.importDocumentDynamicRequest("Update_Lifecycle_Regression",
					"id=1724-administrationId=2-type=CUSTOMER", "type=13,subType=16", "", "", "", "",
					"dossierId=" + dossierId,"", true,
					System.getProperty("user.dir") + "\\JsonFiles\\ImportDocumentDynamic.json",
					System.getProperty("user.dir") + "\\DocumentContents\\DOCX.docx");
			responseBody = importDocument.getPrettifiedResponseBody(response);
			this.jsonObject = new JSONObject(responseBody);
			this.documentId = "drm:" + jsonObject.getString("documentDossierReferenceId");
		} catch (Exception e) {
			test.get(0).skip("@BeforeMethod configuration failed: " + e);
			throw new SkipException("Skipping Test: @BeforeMethod configuration failed: " + e);
		}

	}

	@Test(dataProvider = "getData")
	public void verifyIlLeagalDocumentStatusTest(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException {
		try {
			Response response = updateLifecycleStatus.updateLifecycleStatus(documentId, data.get("Status"));
			String responseBody = updateLifecycleStatus.getPrettifiedResponseBody(response);
			int statusCode = response.getStatusCode();
			JSONArray arrayOfError = new JSONArray(responseBody);
			JSONObject errorObject = new JSONObject();
			errorObject = arrayOfError.getJSONObject(0);
			String message = errorObject.getString("messageText");
			String messageKey = errorObject.getString("messageKey");
			if (statusCode == Integer.parseInt(data.get("Expected Status Code")) && message.equals(data.get("Expected Message")) && messageKey.equals(data.get("Expected Message Code"))) {
				test.get(0).info("Test Data Set: " + data.entrySet().toString());
				test.get(0).pass("Response Status Code Expected: " + data.get("Expected Status Code") + ", Response Status Code Actual: "
						+ updateLifecycleStatus.extentReportFormatter(String.valueOf(statusCode)));
				Assert.assertTrue(true);
			} else {
				test.get(0).info("Test Data Set: " + data.entrySet().toString());
				test.get(0).fail("Response Status Code Expected: 400" + ", Response Status Code Actual: "
						+ updateLifecycleStatus.extentReportFormatter(String.valueOf(statusCode)) + " and the response is : " + responseBody);
				Assert.fail();
			}
		} catch (Exception e) {
			test.get(0).skip("Skipping This test due to exception: " + e);
			Assert.fail();
		}
	}

	@DataProvider(name = "getData")
	public Object[][] getData() {
		return DataUtil
				.loadDataIntoHashTable(
						new Xls_Reader(System.getProperty("user.dir")
								+ "/ExcelFiles/"+prop.getProperty("ENVIRNOMENT")+"/TestData/DocumentService/UpdateLifecycleStatusTestData.xlsx"),
						sheetName);
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws IOException {

	}
	
}
