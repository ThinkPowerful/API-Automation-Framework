package com.rest.documentservice.getSingleDocumentContent.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rest.base.test.BaseTest;
import com.rest.baseservice.BaseOperation;
import com.rest.documentservice.GetSingleDocumentWithContent;
import com.rest.utility.DataUtil;
import com.rest.utility.Xls_Reader;

import io.restassured.response.Response;

public class GetSingleDocumentContentTest extends BaseTest {

	String sheetName = "GetSingleDocumentContentTest";
	GetSingleDocumentWithContent getSingleDocumentWithContent;

	@BeforeClass
	public void initiateTestName() {
		try {
			init(testScenarioName.get("TS81"), authorName.get("TS81"), moduleName.get("TS81"));
			this.getSingleDocumentWithContent = new GetSingleDocumentWithContent();
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
			throw new SkipException("Skipping Test: @BeforeClass configuration failed");
		}
	}

	@Test(dataProvider = "getData")
	public void verifyGetSingleDocumentContentTest(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException {
		try {
			Response response = getSingleDocumentWithContent.getSingleDocument(data.get("Document ID"));
			byte[] singleDocumentContent = response.getBody().asByteArray();
			String documentName = response.getHeader("content-disposition").split("=")[1].replaceAll("\"", "");
			BaseOperation.downloadLocally(singleDocumentContent, documentName.split("\\.")[0],
					documentName.split("\\.")[1]);
			int actualStatusCode = response.getStatusCode();
			if (actualStatusCode == Integer.parseInt(data.get("Expected Status Code"))
					&& BaseOperation.isFileSuccessfullyDownloaded(data.get("Expected File Name").split("\\.")[0], data.get("Expected File Name").split("\\.")[1])) {
				test.get(0).info("Test Data Set: " + data.entrySet().toString());
				test.get(0).pass("Actual status code " + actualStatusCode + " matches with expected status code: "
						+ data.get("Expected Status Code") + " and document successfully downloaded");
				Assert.assertTrue(true);
			} else {
				test.get(0).info("Test Data Set: " + data.entrySet().toString());
				test.get(0).fail("Either status code is not matching or document is not able to download");
				Assert.fail();
			}
		} catch (Exception e) {
			test.get(0).skip("Skipping This test due to exception: " + e);
			Assert.fail();
		}
	}

	@DataProvider(name = "getData")
	public Object[][] getData() {
		return DataUtil
				.loadDataIntoHashTable(
						new Xls_Reader(System.getProperty("user.dir")
								+ "/ExcelFiles/"+prop.getProperty("ENVIRNOMENT")+"/TestData/DocumentService/GetSingleDocumentContentTestData.xlsx"),
						sheetName);
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws IOException {

	}

}
