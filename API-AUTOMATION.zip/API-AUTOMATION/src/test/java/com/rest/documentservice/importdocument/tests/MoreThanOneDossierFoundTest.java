package com.rest.documentservice.importdocument.tests;

import com.rest.base.test.BaseTest;

public class MoreThanOneDossierFoundTest extends BaseTest {
	
	
}
