package com.rest.documentservice.getSingleDocumentContent.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rest.base.test.BaseTest;
import com.rest.documentservice.GetSingleDocumentWithContent;
import com.rest.utility.DataUtil;
import com.rest.utility.Xls_Reader;

import io.restassured.response.Response;

public class ParameterViolationTest extends BaseTest{
	
	String sheetName = "ParameterViolationTest";
	JSONObject jsonObject;
	JSONObject errorObject;
	GetSingleDocumentWithContent getSingleDocumentContent;
	JSONArray errorsArray;
	String dossierID;
	
	@BeforeClass
	public void initiateTestName() {
		try {
			init(testScenarioName.get("TS83"), authorName.get("TS83"), moduleName.get("TS83"));
			this.getSingleDocumentContent = new GetSingleDocumentWithContent();
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
			throw new SkipException("Skipping Test: @BeforeClass configuration failed");
		}
	}

	@Test(dataProvider = "getData")
	public void verifyParameterViolationTest(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException {

		try {
			Response response = getSingleDocumentContent.getSingleDocument(data.get("Document ID"));
			String responseBody = getSingleDocumentContent.getPrettifiedResponseBody(response);
			this.errorsArray = new JSONArray(responseBody);
			this.errorObject = errorsArray.getJSONObject(0);
			String message = errorObject.getString("messageKey");
			String code = errorObject.getString("messageText");
			if (message.equals(data.get("Expected Message Key")) && code.equals(data.get("Expected Message"))) {
				test.get(0).info("Test Data Set: " + data.entrySet().toString());
				test.get(0).pass("Response message, status ,code matches as expected" + ", Response Body "
						+ getSingleDocumentContent.extentReportFormatter(responseBody));
				Assert.assertTrue(true);
			} else {
				test.get(0).info("Test Data Set: " + data.entrySet().toString());
				test.get(0).fail("Response message, status ,code does not matches as expected" + ", Response Body "
						+ getSingleDocumentContent.extentReportFormatter(responseBody));
				Assert.fail();
			}
		} catch (Exception e) {
			test.get(0).skip("Skipping This test due to exception: " + e);
			Assert.fail();
		}

	}

	@DataProvider(name = "getData")
	public Object[][] getData() {
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(
				System.getProperty("user.dir") + "/ExcelFiles/"+prop.getProperty("ENVIRNOMENT")+"/TestData/DocumentService/GetSingleDocumentContentTestData.xlsx"),
				sheetName);
	}

}
