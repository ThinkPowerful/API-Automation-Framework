package com.rest.documentservice.mergedpdfdocumentcontent.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rest.base.test.BaseTest;
import com.rest.baseservice.BaseOperation;
import com.rest.documentservice.GetMergedPdfDocumentContent;
import com.rest.utility.DataUtil;
import com.rest.utility.Xls_Reader;

import io.restassured.path.json.exception.JsonPathException;
import io.restassured.response.Response;

public class GetMergedPdfDocumentContentTest extends BaseTest {

	String sheetName = "MergedPdfDocumentContent";
	GetMergedPdfDocumentContent mergedPdfDocumentContent;
	JSONObject jsonObject;

	@BeforeClass
	public void initiateTestName() {
		try {
			init(testScenarioName.get("TS80"), authorName.get("TS80"), moduleName.get("TS80"));
			this.mergedPdfDocumentContent = new GetMergedPdfDocumentContent();
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
			throw new SkipException("Skipping Test: @BeforeClass configuration failed");
		}
	}

	@Test(dataProvider = "getData")
	public void verifyMergedPdfDocumentContentTest(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException {
		try {
			Response response = mergedPdfDocumentContent.mergePdfDocument(data.get("Document IDs"));
			int statusCode = response.getStatusCode();
			byte[] mergedPdfContent = mergedPdfDocumentContent.mergePdfDocument(data.get("Document IDs")).getBody()
					.asByteArray();
			BaseOperation.downloadLocally(mergedPdfContent, data.get("Expected File Name"), "pdf");
			if (statusCode == 200
					&& BaseOperation.isFileSuccessfullyDownloaded(data.get("Expected File Name"), "pdf")
					/*&& BaseOperation.getFileSizeInMb(data.get("Expected File Name"), "pdf").equals(data.get("Expected File size"))*/ && response.getHeader("X-NonDownloadedIds").equals(data.get("Failed Documents"))) {
				test.get(0).info("Test Data Set: " + data.entrySet().toString());
				test.get(0).pass(
						"Merged pdf functionality is working as expected for DRM and earchive Documents, merged pdf Document downloaded as pdf ,status code.");
				Assert.assertTrue(true);
			} else {
				test.get(0).info("Test Data Set: " + data.entrySet().toString());
				test.get(0).fail(
						"Merged pdf functionality is not working as expected for DRM and earchive Documents, merged pdf Document downloaded as pdf ,status code."); // getDocumentWithContent.createBugInJira("Failed:
				Assert.fail("Merged pdf functionality is not working as expected");
			}

		} catch (JsonPathException e) {
			test.get(0).info("Test Data Set: " + data.entrySet().toString());
			test.get(0).fail("No Response body");
			Assert.fail();
		} catch (Exception e) {
			test.get(0).skip("Skipping This test due to exception: " + e);
			Assert.fail();
		}
	}

	@DataProvider(name = "getData")
	public Object[][] getData() {
		return DataUtil
				.loadDataIntoHashTable(
						new Xls_Reader(System.getProperty("user.dir")
								+ "/ExcelFiles/"+prop.getProperty("ENVIRNOMENT")+"/TestData/DocumentService/MergedPdfDocumentContentTestData.xlsx"),
						sheetName);
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws IOException {

	}

}
