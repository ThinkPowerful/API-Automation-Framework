package com.rest.documentservice.getdocumentwithcontent.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rest.base.test.BaseTest;
import com.rest.baseservice.BaseOperation;
import com.rest.documentservice.GetDocumentWithContent;
import com.rest.utility.DataUtil;
import com.rest.utility.Xls_Reader;

import io.restassured.path.json.exception.JsonPathException;

public class DownloadMultipleDocumentTest extends BaseTest{
	
	String sheetName="DownloadMultipleDocument";
	GetDocumentWithContent getDocumentWithContent;
	JSONObject jsonObject;
	
	@BeforeClass
	public void initiateTestName() 
	{
		try {
			init(testScenarioName.get("TS11"),authorName.get("TS11"),moduleName.get("TS11"));
			this.getDocumentWithContent= new GetDocumentWithContent();
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
			throw new SkipException ("Skipping Test: @BeforeClass configuration failed");
		}
	}
	
	
	@Test(dataProvider="getData")
	public void verifyDownloadMultipleDocumentTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
	{
		try {
			getDocumentWithContent.downloadMultipleDocumentsWithContent(data.get("Document IDs"));
			int statusCode = getDocumentWithContent.downloadMultipleDocumentsWithContent(data.get("Document IDs")).getStatusCode();
			byte[] zipFileDownloaded = getDocumentWithContent.downloadMultipleDocumentsWithContent(data.get("Document IDs")).getBody().asByteArray();
			BaseOperation.downloadLocally(zipFileDownloaded, data.get("Expected Zip File Name"),"zip");
			if(statusCode==200 && BaseOperation.isFileSuccessfullyDownloaded(data.get("Expected Zip File Name"), "zip") && BaseOperation.validateCountInZipFile(data.get("Expected Zip File Name"), data.get("Expected Number Of Documents")))
			{
				test.get(0).info("Test Data Set: "+data.entrySet().toString());
				test.get(0).pass("Zip Download functionality is working as expected for DRM and earchive Documents, Documents downloaded as zip ,status code and number of docs inside zip is matching as expected.");
				Assert.assertTrue(true);
			}
			else
			{
				test.get(0).info("Test Data Set: "+data.entrySet().toString());
				test.get(0).fail("Zip Download functionality is not working as expected for DRM and earchive Documents, Either documents are not downloaded as zip or status code or number of docs is not matching as expected.");
				//getDocumentWithContent.createBugInJira("Failed: "+DownloadMultipleDocumentTest.class.getName(), data.get("FailureTitleInJira")+data.entrySet().toString());
				Assert.fail("Zip Download functionality is not working as expected for DRM Documents");
				
			}
		
		} 
		catch(JsonPathException e)
		{
			test.get(0).info("Test Data Set: "+data.entrySet().toString());
			test.get(0).fail("No Response body");
			//getDocumentWithContent.createBugInJira("Failed: "+data.get("FailureTitleInJira")+OutputRequestAsPdfInvalidTest.class.getName(), data.entrySet().toString());
			Assert.fail();
		}
		catch (Exception e) {
			test.get(0).skip("Skipping This test due to exception: " + e);
			//getDocumentWithContent.createBugInJira("Skipped: "+DownloadMultipleDocumentTest.class.getName(), data.get("FailureTitleInJira")+data.entrySet().toString());
			Assert.fail();
		}
	}
	
	@DataProvider(name="getData")
	public Object[][] getData() 
	{
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"/ExcelFiles/"+prop.getProperty("ENVIRNOMENT")+"/TestData/DocumentService/GetDocumentWithContentTestData.xlsx"), sheetName);
	}
	
	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		
	}

}
