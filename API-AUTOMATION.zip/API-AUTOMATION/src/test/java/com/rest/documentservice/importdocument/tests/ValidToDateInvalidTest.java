package com.rest.documentservice.importdocument.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rest.base.test.BaseTest;
import com.rest.document.constants.ImportDocumentConstants;
import com.rest.documentservice.ImportDocument;
import com.rest.utility.DataUtil;
import com.rest.utility.Xls_Reader;

import io.restassured.path.json.exception.JsonPathException;
import io.restassured.response.Response;

public class ValidToDateInvalidTest extends BaseTest{
	
	String sheetName = "ValidToDateInvalidTest";
	ImportDocument importDocument;
	JSONObject jsonObject;
	JSONObject errorObject;
	JSONArray errorsArray;

	@BeforeClass
	public void initiateTestName() {
		try {
			init(testScenarioName.get("TS73"), authorName.get("TS73"), moduleName.get("TS73"));
			this.importDocument = new ImportDocument();
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
		}
	}

	@Test(dataProvider = "getData")
	public void validToDateInvalidTest(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException {
		String actualResponseBody =null;
		try {
			Response response = importDocument.importDocumentDynamicRequest(data.get("Object Name"),
					data.get("Related Entity"), data.get("Document Type"),"","","",data.get("Valid To Date"),"","",false,
					System.getProperty("user.dir") + "/JsonFiles/" + data.get("Json File Name"),
					System.getProperty("user.dir") + "/DocumentContents/" + data.get("Document Name"));
			String requestBody = ImportDocumentConstants.getImportDocumentRequestBody();
			String prettyRequestBody = importDocument.toPrettyFormat(requestBody);
			actualResponseBody = importDocument.getPrettifiedResponseBody(response);
			JSONObject jsonObject = new JSONObject(actualResponseBody);
			this.errorsArray = jsonObject.getJSONArray("errors");
			this.errorObject = errorsArray.getJSONObject(0);
			String message = errorObject.getString("message");
			String status = String.valueOf(errorObject.getInt("status"));
			String code = errorObject.getString("code");
			if (message.equals(data.get("Expected Message")) && code.equals(data.get("Expected Code"))
					&& status.equals(data.get("Expected Status"))) {
				test.get(0).info("Test Data Set: " + data.entrySet().toString());
				test.get(0).info(importDocument.extentReportFormatter(prettyRequestBody));
				test.get(0).pass("Response message, status ,code matches as expected" + ", Response Body " + " \n"
						+ importDocument.extentReportFormatter(actualResponseBody));
				Assert.assertTrue(true);
			} else {
				test.get(0).info("Test Data Set: " + data.entrySet().toString());
				test.get(0).info(importDocument.extentReportFormatter(prettyRequestBody));
				test.get(0).fail("Response message, status ,code does not matches as expected" + ", Response Body "
						+ importDocument.extentReportFormatter(actualResponseBody));
				// createAnnotation.createBugInJira("Failed:
				// "+data.get("FailureTitleInJira")+ConsumerIDMissingTest.class.getName(),
				// data.entrySet().toString());
				Assert.fail();
			}
		} catch (JsonPathException e) {
			test.get(0).info("Test Data Set: " + data.entrySet().toString());
			test.get(0).fail("No Response body");
			// getDocumentWithContent.createBugInJira("Failed:
			// "+data.get("FailureTitleInJira")+OutputRequestAsPdfInvalidTest.class.getName(),
			// data.entrySet().toString());
			Assert.fail();
		} 
		catch (JSONException e) {
			test.get(0).info("Test Data Set: " + data.entrySet().toString());
			test.get(0).fail("Incorrect Response body: "+importDocument.extentReportFormatter(actualResponseBody));
			// getDocumentWithContent.createBugInJira("Failed:
			// "+data.get("FailureTitleInJira")+OutputRequestAsPdfInvalidTest.class.getName(),
			// data.entrySet().toString());
			Assert.fail();
		}
		catch (Exception e) {
			test.get(0).skip("Skipping This test due to exception: " + e);
			// createAnnotation.createBugInJira("Skipped:
			// "+ConsumerIDMissingTest.class.getName(),
			// data.entrySet().toString());
			Assert.fail();
		}

	}

	@DataProvider(name = "getData")
	public Object[][] getData() {
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")
				+ "/ExcelFiles/"+prop.getProperty("ENVIRNOMENT")+"/TestData/DocumentService/ImportDocumentTestData.xlsx"), sheetName);
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws IOException {

	}

}
