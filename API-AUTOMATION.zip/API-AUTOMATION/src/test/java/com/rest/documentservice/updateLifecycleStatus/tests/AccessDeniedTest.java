package com.rest.documentservice.updateLifecycleStatus.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rest.base.test.BaseTest;
import com.rest.documentservice.UpdateLifecycleStatus;
import com.rest.utility.DataUtil;
import com.rest.utility.Xls_Reader;

import io.restassured.response.Response;

public class AccessDeniedTest extends BaseTest{
	
	String sheetName = "AccessDeniedTest";
	UpdateLifecycleStatus updateLifecycleStatus;
	JSONObject jsonObject;
	
	@BeforeClass
	public void initiateTestName() {
		try {
			init(testScenarioName.get("TS73"), authorName.get("TS73"), moduleName.get("TS73"));
			this.updateLifecycleStatus = new UpdateLifecycleStatus();
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
			throw new SkipException("Skipping Test: @BeforeClass configuration failed");
		}
	}

	@Test(dataProvider = "getData")
	public void verifyAccessDeniedTest(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException {
		try {
			Response response = updateLifecycleStatus.updateLifecycleStatus(data.get("Document Id"), data.get("Status"));
			String responseBody = updateLifecycleStatus.getPrettifiedResponseBody(response);
			int statusCode = response.getStatusCode();
			JSONArray arrayOfError = new JSONArray(responseBody);
			JSONObject errorObject = new JSONObject();
			errorObject = arrayOfError.getJSONObject(0);
			String message = errorObject.getString("messageText");
			String messageKey = errorObject.getString("messageKey");
			if (statusCode == Integer.parseInt(data.get("Expected Status Code")) && message.equals(data.get("Expected Message")) && messageKey.equals(data.get("Expected Message Code"))) {
				test.get(0).info("Test Data Set: " + data.entrySet().toString());
				test.get(0).pass("Response Status Code Expected: " + data.get("Expected Status Code") + ", Response Status Code Actual: "
						+ updateLifecycleStatus.extentReportFormatter(String.valueOf(statusCode)));
				Assert.assertTrue(true);
			} else {
				test.get(0).info("Test Data Set: " + data.entrySet().toString());
				test.get(0).fail("Response Status Code Expected: 400" + ", Response Status Code Actual: "
						+ updateLifecycleStatus.extentReportFormatter(String.valueOf(statusCode)) + " and the response is : " + responseBody);
				Assert.fail();
			}
		} catch (Exception e) {
			test.get(0).skip("Skipping This test due to exception: " + e);
			Assert.fail();
		}
	}

	@DataProvider(name = "getData")
	public Object[][] getData() {
		return DataUtil
				.loadDataIntoHashTable(
						new Xls_Reader(System.getProperty("user.dir")
								+ "/ExcelFiles/"+prop.getProperty("ENVIRNOMENT")+"/TestData/DocumentService/UpdateLifecycleStatusTestData.xlsx"),
						sheetName);
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws IOException {

	}

}
