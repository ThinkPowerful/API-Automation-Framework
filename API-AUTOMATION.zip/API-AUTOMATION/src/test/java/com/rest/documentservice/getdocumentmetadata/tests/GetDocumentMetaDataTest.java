package com.rest.documentservice.getdocumentmetadata.tests;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rest.base.test.BaseTest;
import com.rest.documentservice.GetDocumentMetadata;
import com.rest.utility.DataUtil;
import com.rest.utility.Xls_Reader;

import io.restassured.response.Response;

/**
 * @author C46630
 *
 */
public class GetDocumentMetaDataTest extends BaseTest {

  GetDocumentMetadata getDocumentMetaData;
  String sheetName = "GetDocumentMetaDataTest";

  @BeforeClass
  public void initiateTestName() {
    try {
      init(testScenarioName.get("TS84"), authorName.get("TS84"), moduleName.get("TS84"));
      this.getDocumentMetaData = new GetDocumentMetadata();
    } catch (Exception e) {
      test.get(0).skip("@BeforeClass configuration failed");
      throw new SkipException("Skipping Test: @BeforeClass configuration failed");
    }
  }

  @Test(dataProvider = "getData")
  /**
   * Test Method to verify the Document Metadata
   * 
   * @param data
   */
  public void verifyGetDocumentMetaDataTest(Hashtable<String, String> data) {
    try {
      ArrayList<String> missingDocumentMetaData = new ArrayList<String>();
      Response response = getDocumentMetaData.getDocumentMetaData(data.get("Document ID"));
      int actualStatusCode = response.getStatusCode();
      String actualResponseBody = getDocumentMetaData.getPrettifiedResponseBody(response);
      boolean isMatch = true;
      String[] documentMetaData = data.get("Expected Metadata").split(",");
      for (int i = 0; i < documentMetaData.length; i++) {
        if (!actualResponseBody.contains("\"" + documentMetaData[i].split(":", 2)[0] + "\"" + ": " + "\""
            + documentMetaData[i].split(":", 2)[1] + "\"")) {
          isMatch = false;
          missingDocumentMetaData.add(documentMetaData[i]);
        }
      }
      if (actualStatusCode == Integer.parseInt(data.get("Expected Status")) && isMatch == true) {
        test.get(0).info("Test Data Set: " + data.entrySet().toString());
        test.get(0)
            .pass("Actual status code " + actualStatusCode + " matches with expected status code: "
                + data.get("Expected Status") + " and all the metdata are present in the document. " + " \n"
                + getDocumentMetaData.extentReportFormatter(actualResponseBody));
        Assert.assertTrue(true);
      } else {
        test.get(0).info("Test Data Set: " + data.entrySet().toString());
        test.get(0).fail("Either status code is not matching or the expected metadata is not present in the document. "
            + missingDocumentMetaData + " \n" + getDocumentMetaData.extentReportFormatter(actualResponseBody));
        Assert.fail();
      }

    } catch (Exception e) {
      test.get(0).skip("Skipping This test due to exception: " + e);
      Assert.fail();
    }
  }

  @DataProvider(name = "getData")
  /**
   * Method to Read Test Data from the Resource
   * 
   * @return
   */
  public Object[][] getData() {
    return DataUtil.loadDataIntoHashTable(
        new Xls_Reader(
            System.getProperty("user.dir") + "/ExcelFiles/"+prop.getProperty("ENVIRNOMENT")+"/TestData/DocumentService/GetDocumentMetaDataTestData.xlsx"),
        sheetName);
  }

  @AfterClass(alwaysRun = true)
  public void tearDown() throws IOException {

  }

}
