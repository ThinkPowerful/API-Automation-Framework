package com.rest.documentservice.reusedocuments.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rest.base.test.BaseTest;
import com.rest.documentservice.ReuseDocument;
import com.rest.dossierservice.CreateDossier;
import com.rest.dossierservice.GetDossierDocuments;
import com.rest.utility.DataUtil;
import com.rest.utility.Xls_Reader;

import io.restassured.path.json.exception.JsonPathException;
import io.restassured.response.Response;

public class ReuseDocumentTest extends BaseTest {
	String sheetName = "ReuseDocumentTest";
	ReuseDocument reuseDocument;
	GetDossierDocuments getDossierDocuments;
	CreateDossier createDossier;
	JSONObject jsonObject, getDocumentObject, reuseDocumentObject, getDocumentsList;
	JSONArray getDocumentsArray;
	String dossierID;

	@BeforeClass
	public void initiateTestName() {
		try {
			init(testScenarioName.get("TS27"), authorName.get("TS27"), moduleName.get("TS27"));
			this.reuseDocument = new ReuseDocument();
			this.getDossierDocuments = new GetDossierDocuments();
			this.createDossier = new CreateDossier();
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
			throw new SkipException("Skipping Test: @BeforeClass configuration failed");
		}
	}

	@BeforeMethod
	public void preReqCreateDossier() {
		try {
			Response response = createDossier.createDossier("Rest_1724_28022019");
			String responseBody = createDossier.getPrettifiedResponseBody(response);
			this.jsonObject = new JSONObject(responseBody);
			this.dossierID = jsonObject.getString("dossierId");
		} catch (Exception e) {
			test.get(0).skip("@BeforeMethod configuration failed: " + e);
			throw new SkipException("Skipping Test: @BeforeMethod configuration failed: " + e);
		}
	}

	@Test(dataProvider = "getData")
	public void verifyReuseDocumentTest(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException {
		try {

			Response reuseDocumentResponse = reuseDocument.reuseDocumentInsideDossier(this.dossierID,
					data.get("Document ID"));
			int actualStatusCode = reuseDocumentResponse.getStatusCode();
			String reuseDocumentResponseBody = reuseDocument.getPrettifiedResponseBody(reuseDocumentResponse);
			jsonObject = new JSONObject(reuseDocumentResponseBody);
			this.reuseDocumentObject = jsonObject.getJSONObject("document");
			String reusedDocumentId = reuseDocumentObject.getString("id");
			Thread.sleep(2000);
			Response getDossierDocumentsresponse = getDossierDocuments.getDocumentsInsideDossier(this.dossierID);
			String responseBody = getDossierDocuments.getPrettifiedResponseBody(getDossierDocumentsresponse);
			jsonObject = new JSONObject(responseBody);
			this.getDocumentsArray = jsonObject.getJSONArray("documentsInDossiers");
			this.getDocumentObject = getDocumentsArray.getJSONObject(0);
			String getDocumentId = getDocumentObject.getString("documentDossierReferenceId");
			Thread.sleep(2000);
			if (actualStatusCode == Integer.parseInt(data.get("Expected Status Code"))
					&& getDocumentId.equalsIgnoreCase(reusedDocumentId)) {
				test.get(0).info("Test Data Set: " + data.entrySet().toString());
				test.get(0).pass("Actual status code " + actualStatusCode + " matches with expected status code "+Integer.parseInt(data.get("Expected Status Code")) +" and Response message, status ,code matches as expected, Response Body" + reuseDocument.extentReportFormatter(reuseDocumentResponseBody));
				Assert.assertTrue(true);
			} else {
				test.get(0).info("Test Data Set: " + data.entrySet().toString());
				test.get(0).fail(
						"Actual status code " + actualStatusCode + " does not matches with expected status code 201");
				Assert.fail();
			}

		} catch (JsonPathException e) {
			test.get(0).info("Test Data Set: " + data.entrySet().toString());
			test.get(0).fail("No Response body");
			Assert.fail();
		} catch (Exception e) {
			test.get(0).skip("Skipping This test due to exception: " + e);
			Assert.fail();
		}
	}

	@DataProvider(name = "getData")
	public Object[][] getData() {
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(
				System.getProperty("user.dir") + "/ExcelFiles/"+prop.getProperty("ENVIRNOMENT")+"/TestData/DocumentService/ReuseDocumentTestData.xlsx"),
				sheetName);
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws IOException {

	}
}
