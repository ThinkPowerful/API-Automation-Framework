package com.rest.documentservice.getannotation.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rest.base.test.BaseTest;
import com.rest.documentservice.GetAnnotation;
import com.rest.utility.DataUtil;
import com.rest.utility.Xls_Reader;

import io.restassured.path.json.exception.JsonPathException;
import io.restassured.response.Response;

public class AccessControlTest extends BaseTest{
	
	String sheetName="AccessControlTest";
	GetAnnotation getAnnotation;
	JSONObject jsonObject;
	JSONObject errorObject;
	JSONArray errorsArray; 

		@BeforeClass
		public void initiateTestName() 
		{
			try {
				init(testScenarioName.get("TS51"),authorName.get("TS51"),moduleName.get("TS51"));
				this.getAnnotation= new GetAnnotation();
			} catch (Exception e) {
				test.get(0).skip("@BeforeClass configuration failed");
				throw new SkipException ("Skipping Test: @BeforeClass configuration failed");
			}
		}

		@Test(dataProvider="getData")
		public void verifyAccessControlTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
		{
			try {
				Response response = getAnnotation.getAnnotationForDocuments( data.get("Document ID"));
				String responseBody = getAnnotation.getPrettifiedResponseBody(response);
				JSONObject jsonObject = new JSONObject(responseBody);
				this.errorsArray = jsonObject.getJSONArray("errors");
				this.errorObject = errorsArray.getJSONObject(0);
				String message = errorObject.getString("message");
				String status = String.valueOf(errorObject.getInt("status"));
				String code = errorObject.getString("code");
				if (message.equals(data.get("Expected Message")) &&  code.equals(data.get("Expected Code")) &&  status.equals(data.get("Expected Status"))) 
					{
					test.get(0).info("Test Data Set: "+data.entrySet().toString());
					test.get(0).pass("Response message, status ,code matches as expected"+", Response Body " + getAnnotation.extentReportFormatter(responseBody));
					Assert.assertTrue(true);
				} else {
					test.get(0).info("Test Data Set: "+data.entrySet().toString());
					test.get(0).fail("Response message, status ,code does not matches as expected"+", Response Body " + getAnnotation.extentReportFormatter(responseBody));
					//getDocumentWithContent.createBugInJira("Failed: "+data.get("FailureTitleInJira")+DocumentIDMissingTest.class.getName(), data.entrySet().toString());
					Assert.fail();
				} 
			}
			catch(JsonPathException e)
			{
				test.get(0).info("Test Data Set: "+data.entrySet().toString());
				test.get(0).fail("No Response body");
				//getDocumentWithContent.createBugInJira("Failed: "+data.get("FailureTitleInJira")+OutputRequestAsPdfInvalidTest.class.getName(), data.entrySet().toString());
				Assert.fail();
			}
			catch (Exception e) {
				test.get(0).skip("Skipping This test due to exception: " + e);
				//getDocumentWithContent.createBugInJira("Skipped: "+DocumentIDMissingTest.class.getName(), data.entrySet().toString());
				Assert.fail();
			}
		}

		@DataProvider(name="getData")
		public Object[][] getData() 
		{
			return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"/ExcelFiles/"+prop.getProperty("ENVIRNOMENT")+"/TestData/DocumentService/GetAnnotationTestData.xlsx"), sheetName);
		}

		@AfterClass(alwaysRun=true)
		public void tearDown() throws IOException
		{
			
		}

}
