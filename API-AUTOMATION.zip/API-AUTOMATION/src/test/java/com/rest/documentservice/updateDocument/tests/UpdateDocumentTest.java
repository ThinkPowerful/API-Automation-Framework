package com.rest.documentservice.updateDocument.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rest.base.test.BaseTest;
import com.rest.document.constants.UpdateDocumentConstants;
import com.rest.documentservice.GetDocumentMetadata;
import com.rest.documentservice.ImportDocument;
import com.rest.documentservice.UpdateDocument;
import com.rest.utility.DataUtil;
import com.rest.utility.Xls_Reader;

import io.restassured.response.Response;

public class UpdateDocumentTest extends BaseTest {

	String sheetName = "UpdateDocumentTest";
	UpdateDocument updateDocument;
	ImportDocument importDocument;
	JSONObject jsonObject;
	String documentId;
	GetDocumentMetadata getDocumentmetadata;

	@BeforeClass
	public void initiateTestName() {
		try {
			init(testScenarioName.get("TS89"), authorName.get("TS89"), moduleName.get("TS89"));
			this.updateDocument = new UpdateDocument();
			this.importDocument = new ImportDocument();
			this.getDocumentmetadata = new GetDocumentMetadata();
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
			throw new SkipException("Skipping Test: @BeforeClass configuration failed");
		}
	}
	
	@BeforeMethod
	public void preReqImportDocument() {
		try {
			Response response = importDocument.importDocumentDynamicRequest("Update_Document_Regression", "id=1724-administrationId=2-type=CUSTOMER", "type=7,subType=7", "", "", "", "", "","/RK/workspaces/NL", false, System.getProperty("user.dir") + "/JsonFiles/ImportDocumentDynamic.json", System.getProperty("user.dir") + "/DocumentContents/DOCX.docx");
			String responseBody = importDocument.getPrettifiedResponseBody(response);
			this.jsonObject = new JSONObject(responseBody);
			this.documentId = jsonObject.getString("documentId");
			//this.documentId = documentId.substring(4);
		} catch (Exception e) {
			test.get(0).skip("@BeforeMethod configuration failed: " + e);
			throw new SkipException("Skipping Test: @BeforeMethod configuration failed: " + e);
		}

	}

	@Test(dataProvider = "getData")
	public void verifyUpdateDocumentTest(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException {

		try {
			Response response = updateDocument.updateDocumentWithAllParameters(this.documentId,
					data.get("Source ID"), data.get("Title"), data.get("Description"), data.get("Source Label"),
					data.get("Access Type"), data.get("Security Level"), data.get("Document Name"), data.get("Source"),
					data.get("Status"), data.get("Related entity"), data.get("Scope Info"), data.get("Actions list"),
					data.get("Retention Period"), data.get("Availability Rating"), data.get("Legal hold status"),
					data.get("Document Type"), data.get("Scan status"), data.get("Validity Status"),
					data.get("Content size"), data.get("Content type"), data.get("Document Validity Status"),
					data.get("Annotation Info Available"), data.get("Valid From Date"), data.get("Valid To Date"),
					data.get("Event Date"), data.get("Version Label"), data.get("Additional Attribute"),
					data.get("Authors"));
			int actualStatusCode = response.getStatusCode();
			// get document and check the metadata
			Thread.sleep(20000);

			ArrayList<String> missingDocumentMetaData = new ArrayList<String>();

			Response getDocument = getDocumentmetadata.getDocumentMetaData(documentId.substring(4));
			String actualResponseBody = getDocumentmetadata.getPrettifiedResponseBody(getDocument);
			String[] expectedDocumentMetadata = data.get("Expected Metadata").split(";");
			boolean isMatch = true;
			for (int i = 0; i < expectedDocumentMetadata.length; i++) {

				if (!actualResponseBody.contains("\"" + expectedDocumentMetadata[i].split(":", 2)[0] + "\"" + ": "
						+ "\"" + expectedDocumentMetadata[i].split(":", 2)[1])) {
					isMatch = false;
					missingDocumentMetaData.add(expectedDocumentMetadata[i]);
					break;
				}
			}

			if (actualStatusCode == Integer.parseInt(data.get("Expected Status Code")) && isMatch) {
				test.get(0).info("Test Data Set: " + data.entrySet().toString());
				test.get(0).pass("Actual status code " + actualStatusCode + " matches with expected status code "
						+ Integer.parseInt(data.get("Expected Status Code")));
				Assert.assertTrue(true);
			} else {
				test.get(0).info("Test Data Set: " + data.entrySet().toString());
				test.get(0).fail(
						"Either status code is not matching or the expected metadata is not present in the document. "
								+ missingDocumentMetaData + " \n"
								+ updateDocument.extentReportFormatter(actualResponseBody));
				Assert.fail();
			}
		} catch (Exception e) {
			test.get(0).skip("Skipping This test due to exception: " + e);
			Assert.fail();
		}

	}

	@DataProvider(name = "getData")
	public Object[][] getData() {
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")
				+ "/ExcelFiles/"+prop.getProperty("ENVIRNOMENT")+"/TestData/DocumentService/UpdateDocumentTestData.xlsx"), sheetName);
	}

}
