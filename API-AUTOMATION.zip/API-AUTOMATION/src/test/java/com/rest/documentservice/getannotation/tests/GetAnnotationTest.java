package com.rest.documentservice.getannotation.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rest.base.test.BaseTest;
import com.rest.documentservice.CreateAnnotation;
import com.rest.documentservice.GetAnnotation;
import com.rest.utility.DataUtil;
import com.rest.utility.Utility;
import com.rest.utility.Xls_Reader;

import io.restassured.response.Response;

public class GetAnnotationTest extends BaseTest{
	
	String sheetName="GetAnnotationTest";
	CreateAnnotation createAnnotation;
	GetAnnotation getAnnotation;
	String dynamicAnnotationText;
	
	@BeforeClass
	public void initiateTestName() 
	{
		try {
			init(testScenarioName.get("TS50"),authorName.get("TS50"),moduleName.get("TS50"));
			this.getAnnotation= new GetAnnotation();
			this.createAnnotation= new CreateAnnotation();
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
			throw new SkipException ("Skipping Test: @BeforeClass configuration failed");
		}
	}
	
	
	@Test(dataProvider="getData")
	public void verifyGetAnnotationTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
	{
		try {
			dynamicAnnotationText=Utility.randomAlphaNumeric(30);
			createAnnotation.createAnnotationForDocuments(data.get("Document ID"), dynamicAnnotationText);
			Thread.sleep(5000);
			Response response = getAnnotation.getAnnotationForDocuments(data.get("Document ID"));
			String actualResponseBody = getAnnotation.getPrettifiedResponseBody(response);
			int actualStatusCode = response.getStatusCode();
			if (actualStatusCode==Integer.parseInt(data.get("Expected Status Code")) && actualResponseBody.contains(dynamicAnnotationText)) 
				{
				test.get(0).info("Test Data Set: "+data.entrySet().toString());
				test.get(0).pass("Actual status code "+actualStatusCode+" matches with expected status code: "+data.get("Expected Status Code")+" and document successfully annotated with the comment: "
				+dynamicAnnotationText+" \n"+getAnnotation.extentReportFormatter(actualResponseBody));
				Assert.assertTrue(true);
			} else {
				test.get(0).info("Test Data Set: "+data.entrySet().toString());
				test.get(0).fail("Either status code is not matching or document is not annotated with the comment "+dynamicAnnotationText+"\n"+getAnnotation.extentReportFormatter(actualResponseBody));
				//createAnnotation.createBugInJira("Failed: "+data.get("FailureTitleInJira")+ConsumerIDMissingTest.class.getName(), data.entrySet().toString());
				Assert.fail();
			} 
		}
		catch (Exception e) {
			test.get(0).skip("Skipping This test due to exception: " + e);
			//createAnnotation.createBugInJira("Skipped: "+ConsumerIDMissingTest.class.getName(), data.entrySet().toString());
			Assert.fail();
		}
	}
	
	@DataProvider(name="getData")
	public Object[][] getData() 
	{
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"/ExcelFiles/"+prop.getProperty("ENVIRNOMENT")+"/TestData/DocumentService/GetAnnotationTestData.xlsx"), sheetName);
	}
	
	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		
	}

}
