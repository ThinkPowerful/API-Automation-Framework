package com.rest.documentservice.getdocumentwithcontent.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rest.base.test.BaseTest;
import com.rest.baseservice.BaseOperation;
import com.rest.documentservice.GetDocumentWithContent;
import com.rest.utility.DataUtil;
import com.rest.utility.Xls_Reader;

import io.restassured.path.json.exception.JsonPathException;

public class DownloadSingleDocumentTest extends BaseTest{
	
	String sheetName="DownloadSingleDocument";
	GetDocumentWithContent getDocumentWithContent;
	JSONObject jsonObject;
	
	@BeforeClass
	public void initiateTestName() 
	{
		try {
			init(testScenarioName.get("TS19"),authorName.get("TS19"),moduleName.get("TS19"));
			this.getDocumentWithContent= new GetDocumentWithContent();
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
			throw new SkipException ("Skipping Test: @BeforeClass configuration failed");
		}
	}
	
	
	@Test(dataProvider="getData")
	public void verifyDownloadSingleDocumentTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
	{
		try {
			int statusCode = getDocumentWithContent.downloadOneOrMultipleDocumentsWithContent(data.get("Document IDs"),"application/pdf").getStatusCode();
			byte[] pdfFileDownloaded = getDocumentWithContent.downloadOneOrMultipleDocumentsWithContent(data.get("Document IDs"),"application/pdf").getBody().asByteArray();
			BaseOperation.downloadLocally(pdfFileDownloaded, data.get("Expected PDF File Name"),"pdf");
			if(statusCode==200 && BaseOperation.isFileSuccessfullyDownloaded(data.get("Expected PDF File Name"), "pdf"))
			{
				test.get(0).info("Test Data Set: "+data.entrySet().toString());
				test.get(0).pass("PDF Download functionality is working as expected for DRM and earchive Documents, Status code and document name is matching as expected.");
				Assert.assertTrue(true);
			}
			else
			{
				test.get(0).info("Test Data Set: "+data.entrySet().toString());
				test.get(0).fail("PDF Download functionality is not working as expected for DRM and earchive Documents, Either status code or document name is not matching as expected.");
				//getDocumentWithContent.createBugInJira("Failed: "+DownloadMultipleDocumentTest.class.getName(), data.get("FailureTitleInJira")+data.entrySet().toString());
				Assert.fail("PDF Download functionality is not working as expected for DRM Documents");
				
			}
		
		} 
		catch(JsonPathException e)
		{
			test.get(0).info("Test Data Set: "+data.entrySet().toString());
			test.get(0).fail("No Response body");
			//getDocumentWithContent.createBugInJira("Failed: "+data.get("FailureTitleInJira")+OutputRequestAsPdfInvalidTest.class.getName(), data.entrySet().toString());
			Assert.fail();
		}
		catch (Exception e) {
			test.get(0).skip("Skipping This test due to exception: " + e);
			//getDocumentWithContent.createBugInJira("Skipped: "+DownloadMultipleDocumentTest.class.getName(), data.get("FailureTitleInJira")+data.entrySet().toString());
			Assert.fail();
		}
	}
	
	@DataProvider(name="getData")
	public Object[][] getData() 
	{
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"/ExcelFiles/"+prop.getProperty("ENVIRNOMENT")+"/TestData/DocumentService/GetDocumentWithContentTestData.xlsx"), sheetName);
	}
	
	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		
	}

}
