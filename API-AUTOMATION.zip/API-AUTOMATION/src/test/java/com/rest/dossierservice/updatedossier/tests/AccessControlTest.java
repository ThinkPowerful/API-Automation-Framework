package com.rest.dossierservice.updatedossier.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rest.base.test.BaseTest;
import com.rest.dossierservice.UpdateDossier;
import com.rest.utility.DataUtil;
import com.rest.utility.Xls_Reader;

import io.restassured.path.json.exception.JsonPathException;
import io.restassured.response.Response;

public class AccessControlTest extends BaseTest {

	String sheetName = "AccessControlTest";
	UpdateDossier updateDossier;
	JSONObject jsonObject;
	JSONObject errorObject;
	JSONArray errorsArray;

	@BeforeClass
	public void initiateTestName() {
		try {
			init(testScenarioName.get("TS79"), authorName.get("TS79"), moduleName.get("TS79"));
			this.updateDossier = new UpdateDossier();
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
			throw new SkipException("Skipping Test: @BeforeClass configuration failed");
		}
	}

	@Test(dataProvider = "getData")
	public void verifyAccessControlTest(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException {
		try {
			Response response = updateDossier.updateDossierWithMandatoryAndOptionalParameters(data.get("Dossier Id"),
					data.get("Source ID"), data.get("Creation Date Time"), data.get("Creator Consumer Id"),
					data.get("Last Modifier User Id"), data.get("Last Modified Timestamp"), data.get("Title"),
					data.get("Description"), data.get("Source Label"), data.get("Access Type"),
					data.get("Security Level"), data.get("Dossier Name"), data.get("Dossier Type"), data.get("status"),
					data.get("Related entity"), data.get("Dossier Context Info"), data.get("Scope Info"),
					data.get("Actions list"), data.get("Retention Period"), data.get("Availability Rating"));
			String responseBody = updateDossier.getPrettifiedResponseBody(response);
			JSONObject jsonObject = new JSONObject(responseBody);
			this.errorsArray = jsonObject.getJSONArray("errors");
			this.errorObject = errorsArray.getJSONObject(0);
			String message = errorObject.getString("message");
			String status = String.valueOf(errorObject.getInt("status"));
			String code = errorObject.getString("code");
			if (message.equals(data.get("Expected Message")) && code.equals(data.get("Expected Code"))
					&& status.equals(data.get("Expected Status Code"))) {
				test.get(0).info("Test Data Set: " + data.entrySet().toString());
				test.get(0).pass("Response message, status ,code matches as expected" + ", Response Body "
						+ updateDossier.extentReportFormatter(responseBody));
				Assert.assertTrue(true);
			} else {
				test.get(0).info("Test Data Set: " + data.entrySet().toString());
				test.get(0).fail("Response message, status ,code does not matches as expected" + ", Response Body "
						+ updateDossier.extentReportFormatter(responseBody));
				Assert.fail();
			}
		} catch (JsonPathException e) {
			test.get(0).info("Test Data Set: " + data.entrySet().toString());
			test.get(0).fail("No Response body");
			Assert.fail();
		} catch (Exception e) {
			test.get(0).skip("Skipping This test due to exception: " + e);
			Assert.fail();
		}
	}

	@DataProvider(name = "getData")
	public Object[][] getData() {
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(
				System.getProperty("user.dir") + "/ExcelFiles/"+prop.getProperty("ENVIRNOMENT")+"/TestData/DossierService/UpdateDossierTestData.xlsx"),
				sheetName);
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws IOException {

	}

}
