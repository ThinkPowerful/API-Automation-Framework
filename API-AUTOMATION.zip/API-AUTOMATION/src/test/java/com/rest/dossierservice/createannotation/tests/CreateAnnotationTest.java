package com.rest.dossierservice.createannotation.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rest.base.test.BaseTest;
import com.rest.dossierservice.CreateAnnotation;
import com.rest.utility.DataUtil;
import com.rest.utility.Xls_Reader;

public class CreateAnnotationTest extends BaseTest{

	String sheetName="CreateAnnotationTest";
	CreateAnnotation createAnnotation;
	
	@BeforeClass
	public void initiateTestName() 
	{
		try {
			init(testScenarioName.get("TS42"),authorName.get("TS42"),moduleName.get("TS42"));
			this.createAnnotation= new CreateAnnotation();
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
			throw new SkipException ("Skipping Test: @BeforeClass configuration failed");
		}
	}
	
	@Test(dataProvider="getData")
	public void verifyCreateAnnotationTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
	{
		try {
			int actualStatusCode = createAnnotation.createAnnotationForDossier(data.get("Dossier ID"), data.get("Annotation Text")).getStatusCode();
			if (actualStatusCode==204) 
				{
				test.get(0).info("Test Data Set: "+data.entrySet().toString());
				test.get(0).pass("Actual status code "+actualStatusCode+" matches with expected status code 204");
				Assert.assertTrue(true);
			} else {
				test.get(0).info("Test Data Set: "+data.entrySet().toString());
				test.get(0).fail("Actual status code "+actualStatusCode+" does not matches with expected status code 204");
				//createAnnotation.createBugInJira("Failed: "+data.get("FailureTitleInJira")+ConsumerIDMissingTest.class.getName(), data.entrySet().toString());
				Assert.fail();
			} 
		}
		catch (Exception e) {
			test.get(0).skip("Skipping This test due to exception: " + e);
			//createAnnotation.createBugInJira("Skipped: "+ConsumerIDMissingTest.class.getName(), data.entrySet().toString());
			Assert.fail();
		}
	}
	
	@DataProvider(name="getData")
	public Object[][] getData() 
	{
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"/ExcelFiles/"+prop.getProperty("ENVIRNOMENT")+"/TestData/DossierService/CreateAnnotationTestData.xlsx"), sheetName);
	}
	
	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		
	}
	
}
