package com.rest.dossierservice.closedossier.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rest.base.test.BaseTest;
import com.rest.dossierservice.CloseDossier;
import com.rest.utility.DataUtil;
import com.rest.utility.Xls_Reader;

import io.restassured.response.Response;

public class DossierNotFoundTest extends BaseTest{
	
	String sheetName="DossierNotFound";
	CloseDossier closeDossier;
	JSONObject jsonObject;
	JSONObject errorObject;
	JSONArray errorsArray; 
	
	@BeforeClass
	public void initiateTestName() 
	{
		try {
			init(testScenarioName.get("TS08"),authorName.get("TS08"),moduleName.get("TS08"));
			this.closeDossier= new CloseDossier();
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
			throw new SkipException ("Skipping Test: @BeforeClass configuration failed");
		}
	}
	
	@Test(dataProvider="getData")
	public void verifyCloseDossierTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
	{
		try {
			Response response = closeDossier.closeDossier(data.get("Dossier ID"), data.get("Dossier Status"));
			String responseBody = closeDossier.getPrettifiedResponseBody(response);
			JSONObject jsonObject = new JSONObject(responseBody);
			this.errorsArray = jsonObject.getJSONArray("errors");
			this.errorObject = errorsArray.getJSONObject(0);
			String message = errorObject.getString("message");
			String status = String.valueOf(errorObject.getInt("status"));
			String code = errorObject.getString("code");
			if (message.equals(data.get("Expected Message")) &&  code.equals(data.get("Expected Code")) &&  status.equals(data.get("Expected Status"))) 
				{
				test.get(0).info("Test Data Set: "+data.entrySet().toString());
				test.get(0).pass("Response message, status ,code matches as expected"+", Response Body " + closeDossier.extentReportFormatter(responseBody));
				Assert.assertTrue(true);
			} else {
				test.get(0).info("Test Data Set: "+data.entrySet().toString());
				test.get(0).fail("Response message, status ,code does not matches as expected"+", Response Body " + closeDossier.extentReportFormatter(responseBody));
				//closeDossier.createBugInJira("Failed: "+data.get("FailureTitleInJira")+DossierNotFoundTest.class.getName(), data.entrySet().toString());
				Assert.fail();
			} 
		} catch (Exception e) {
			test.get(0).skip("Skipping This test due to exception: " + e);
			//closeDossier.createBugInJira("Skipped: "+DossierNotFoundTest.class.getName(), data.entrySet().toString());
			Assert.fail();
		}
	}
	
	@DataProvider(name="getData")
	public Object[][] getData() 
	{
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"/ExcelFiles/"+prop.getProperty("ENVIRNOMENT")+"/TestData/DossierService/CloseDossierTestData.xlsx"), sheetName);
	}
	
	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		
	}

}
