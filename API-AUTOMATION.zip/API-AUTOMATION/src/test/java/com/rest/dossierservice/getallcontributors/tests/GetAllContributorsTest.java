package com.rest.dossierservice.getallcontributors.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rest.base.test.BaseTest;
import com.rest.dossierservice.AddContributor;
import com.rest.dossierservice.CloseDossier;
import com.rest.dossierservice.CreateDossier;
import com.rest.dossierservice.GetAllContributor;
import com.rest.utility.DataUtil;
import com.rest.utility.Xls_Reader;

import io.restassured.response.Response;
import io.restassured.response.ResponseBody;

public class GetAllContributorsTest extends BaseTest{
	
	String sheetName="GetAllContributorTest";
	AddContributor addContributor;
	GetAllContributor getAllContributor;
	CreateDossier createDossier;
	JSONObject jsonObject;
	String dossierID;
	
	@BeforeClass
	public void initiateTestName() 
	{
		try {
			init(testScenarioName.get("TS97"),authorName.get("TS97"),moduleName.get("TS97"));
			this.createDossier= new CreateDossier();
			this.addContributor= new AddContributor();
			this.getAllContributor = new GetAllContributor();
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
			throw new SkipException ("Skipping Test: @BeforeClass configuration failed");
		}
	}
	
	@BeforeMethod
	public void preReqCreateDossier()
	{
		try {
			Response response = createDossier.createDossier("Rest_1724_28022019");
			String responseBody = createDossier.getPrettifiedResponseBody(response);
			this.jsonObject = new JSONObject(responseBody);
			this.dossierID = jsonObject.getString("dossierId");
		} catch (Exception e) {
			test.get(0).skip("@BeforeMethod configuration failed: "+e);
			throw new SkipException ("Skipping Test: @BeforeMethod configuration failed: "+e);
		}
		
	}
	
	@Test(dataProvider="getData")
	public void verifyCloseDossierTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
	{
		try {
			addContributor.addContributorForDossier(this.dossierID, data.get("Contributors Added"));
			Response response =getAllContributor.getAllContributorsOfDossier(this.dossierID);
			int statusCode=response.getStatusCode();
			String actualResponseBody = addContributor.getPrettifiedResponseBody(response);
			if (statusCode == Integer.parseInt(data.get("Expected Status Code"))) {
				test.get(0).info("Test Data Set: "+data.entrySet().toString());
				test.get(0).pass("Response Status Code Expected: 200"+", Response Status Code Actual: " + getAllContributor.extentReportFormatter(actualResponseBody));
				Assert.assertTrue(true);
			} else {
				test.get(0).info("Test Data Set: "+data.entrySet().toString());
				test.get(0).fail("Response Status Code Expected: 200"+", Response Status Code Actual: " + getAllContributor.extentReportFormatter(actualResponseBody));
				//addContributorForDossier.createBugInJira("Failed: "+CloseDossierTest.class.getName(), data.get("FailureTitleInJira")+data.entrySet().toString());
				Assert.fail();
			} 
		} catch (Exception e) {
			test.get(0).skip("Skipping This test due to exception: " + e);
			//addContributorForDossier.createBugInJira("Skipped: "+CloseDossierTest.class.getName(), data.get("FailureTitleInJira")+data.entrySet().toString());
			Assert.fail();
		}
	}
	
	@DataProvider(name="getData")
	public Object[][] getData() 
	{
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"/ExcelFiles/"+prop.getProperty("ENVIRNOMENT")+"/TestData/DossierService/GetAllContributorTestData.xlsx"), sheetName);
	}
	
	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		
	}

}
