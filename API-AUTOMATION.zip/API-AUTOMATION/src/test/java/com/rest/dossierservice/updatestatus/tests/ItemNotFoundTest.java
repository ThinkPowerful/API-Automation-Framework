package com.rest.dossierservice.updatestatus.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rest.base.test.BaseTest;
import com.rest.dossierservice.UpdateStatus;
import com.rest.utility.DataUtil;
import com.rest.utility.Xls_Reader;

import io.restassured.response.Response;

public class ItemNotFoundTest extends BaseTest{
	
	String sheetName="ItemNotFound";
	UpdateStatus updateDossierStatus;
	
	@BeforeClass
	public void initiateTestName() 
	{
		try {
			init(testScenarioName.get("TS03"),authorName.get("TS03"),moduleName.get("TS03"));
			this.updateDossierStatus= new UpdateStatus();
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
			throw new SkipException ("Skipping Test: @BeforeClass configuration failed");
		}
	}
	
	@Test(dataProvider="getData")
	public void verifyItemNotFoundTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
	{
		try {
			Response response = updateDossierStatus.updateDossierStatus(data.get("Dossier ID"),"CLOSED");
			int responseStatusCode = updateDossierStatus.getResponseStatusCode(response);
			String responseBody = updateDossierStatus.getPrettifiedResponseBody(response);
			if (responseStatusCode == 404 && responseBody.contains(data.get("Expected Exception"))) {
				test.get(0).info("Test Data Set: "+data.entrySet().toString());
				test.get(0).pass("Response Status Code Expected: 404"+", Response Status Code Actual: " + updateDossierStatus.extentReportFormatter(String.valueOf(responseStatusCode)));
				test.get(0).pass("Response body contain: "+data.get("Expected Exception")+updateDossierStatus.extentReportFormatter(responseBody));
				Assert.assertTrue(true);
			} else {
				test.get(0).info("Test Data Set: "+data.entrySet().toString());
				test.get(0).fail("Response Status Code Expected: 404"+", Response Status Code Expected " + updateDossierStatus.extentReportFormatter(String.valueOf(responseStatusCode)));
				test.get(0).fail("Response body does not contain: "+data.get("Expected Exception")+updateDossierStatus.extentReportFormatter(responseBody));
				//updateDossierStatus.createBugInJira(data.entrySet().toString(), data.entrySet().toString());
				Assert.fail();
			} 
			
		} catch (Exception e) {
			test.get(0).info("Test Data Set: "+data.entrySet().toString());
			test.get(0).skip("Skipping This test due to exception: " + e);
			//updateDossierStatus.createBugInJira(data.entrySet().toString(), data.entrySet().toString());
			Assert.fail();
		}
	}
	
	@DataProvider(name="getData")
	public Object[][] getData() 
	{
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"/ExcelFiles/"+prop.getProperty("ENVIRNOMENT")+"/TestData/DossierService/UpdateStatusTestData.xlsx"), sheetName);
	}
	
	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		
	}

}
