package com.rest.dossierservice.searchdossier.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rest.base.test.BaseTest;
import com.rest.dossier.constants.SearchDossierConstants;
import com.rest.dossierservice.CreateDossier;
import com.rest.dossierservice.SearchDossier;
import com.rest.utility.DataUtil;
import com.rest.utility.DateUtil;
import com.rest.utility.Xls_Reader;

import io.restassured.response.Response;

public class SearchDossierTest extends BaseTest {

	String sheetName = "SearchDossierTest";
	SearchDossier searchDossier;
	CreateDossier createDossier;
	JSONObject jsonObject;
	JSONObject errorObject;
	JSONArray errorsArray;
	String dossierID;
	String currentDate;

	@BeforeClass
	public void initiateTestName() {
		try {
			init(testScenarioName.get("TS56"), authorName.get("TS56"), moduleName.get("TS56"));
			this.searchDossier = new SearchDossier();
			this.createDossier = new CreateDossier();
			this.currentDate = DateUtil.convertDateToStringInYearMonthDate(DateUtil.getCurrentdateInYearMonthDate());
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
		}
	}

	@Test(dataProvider = "getData")
	public void verifySearchDossierTest(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException {

		try {
			Response createDossierResponse = createDossier.createDossierWithMultipleRelatedEntityInfo(
					data.get("Create-Dossier Name"), data.get("Create-Title"), data.get("Create-Description"),
					data.get("Create-Source ID"), data.get("Create-Source Label"),
					data.get("Create-Related Entity Triplet"), data.get("Create-Retention Period"),
					data.get("Create-Retention Start Date Time"), data.get("Create-Retention End Date Time"),
					data.get("Create-Scope Administration ID"), data.get("Create-Scope Type"),
					data.get("Create-Scope Value"), data.get("Create-Security Level"),
					data.get("Create-Confidentiality Rating"), data.get("Create-Integrity Rating"),
					data.get("Create-Availability Rating"), data.get("Create-Security Classifier"),
					data.get("Create-Dossier Type"), data.get("Create-Dossier Context Value"),
					data.get("Create-Dossier Context Type"), data.get("Create-Dossier Context Admin"));
			int createDossierActualStatusCode = createDossierResponse.getStatusCode();
			String actualCreateDossierResponseBody = createDossier.getPrettifiedResponseBody(createDossierResponse);
			JSONObject jsonObject = new JSONObject(actualCreateDossierResponseBody);
			this.dossierID = jsonObject.get("dossierId").toString();
			if (createDossierActualStatusCode == Integer.parseInt("200")) {
				test.get(0).info("Dossier Created Successfully");
				Response searchDossierResponse = searchDossier.SearchDossierWithAllParameters(
						data.get("Search-Contition Type"), data.get("Search-Related Entity Info"),
						data.get("Search-Dossier Name and Query type"),
						"fromDate=" + currentDate + ",toDate=" + currentDate, data.get("Search-Page Number"),
						data.get("Search-Page Size"), "fromDate=" + currentDate + ",toDate=" + currentDate,
						data.get("Search-Creator Consumer Id"), data.get("Search-Last Modified User ID"),
						data.get("Search-SourceID"), data.get("Search-Sort By"), data.get("Search-Description"));
				int searhDossierActualStatusCode = searchDossierResponse.getStatusCode();
				String actualResponseBodyOfSearchDossier = searchDossier
						.getPrettifiedResponseBody(searchDossierResponse);
				String requestBodyOfSearchDossier = SearchDossierConstants
						.getSearchDossierRequestBodyWithAllParameters();
				String prettyRequestBodyOfSearchDossier = searchDossier.toPrettyFormat(requestBodyOfSearchDossier);
				System.out.println(prettyRequestBodyOfSearchDossier);
				if (searhDossierActualStatusCode == Integer.parseInt(data.get("Expected Status Code"))
						&& actualResponseBodyOfSearchDossier.contains("\"dossierId\": " + "\"" + dossierID + "\"")) {
					test.get(0).info("Test Data Set: " + data.entrySet().toString());
					test.get(0).info(
							"Request Body: " + searchDossier.extentReportFormatter(prettyRequestBodyOfSearchDossier));
					test.get(0)
							.pass("Actual status code " + searhDossierActualStatusCode
									+ " matches with expected status code 200 and expected dossier " + dossierID
									+ " found in the search results" + " \n"
									+ searchDossier.extentReportFormatter(actualResponseBodyOfSearchDossier));
					Assert.assertTrue(true);
				} else {
					test.get(0).info("Test Data Set: " + data.entrySet().toString());
					test.get(0).info(
							"Request Body: " + searchDossier.extentReportFormatter(prettyRequestBodyOfSearchDossier));
					test.get(0)
							.fail("Actual status code " + searhDossierActualStatusCode
									+ " does not matches with the expected status code 200 and expected dossier "
									+ dossierID + " not found in the search results" + " \n"
									+ searchDossier.extentReportFormatter(actualResponseBodyOfSearchDossier));
					Assert.fail();
				}

			} else {
				test.get(0).info("Dossier Creation Failed");
				test.get(0).skip("Skipping This test due to the pre-req dossier creation failed");
			}

		} catch (Exception e) {
			test.get(0).skip("Skipping This test due to exception: " + e);
			// createAnnotation.createBugInJira("Skipped:
			// "+ConsumerIDMissingTest.class.getName(),
			// data.entrySet().toString());
			Assert.fail();
		}

	}

	@DataProvider(name = "getData")
	public Object[][] getData() {
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir") + "/ExcelFiles/"
				+ prop.getProperty("ENVIRNOMENT") + "/TestData/DossierService/SearchDossiersTestData.xlsx"), sheetName);
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws IOException {

	}

}
