package com.rest.dossierservice.addcontributor.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rest.base.test.BaseTest;
import com.rest.dossier.constants.AddContributorConstants;
import com.rest.dossierservice.AddContributor;
import com.rest.dossierservice.CreateDossier;
import com.rest.utility.DataUtil;
import com.rest.utility.Xls_Reader;

import io.restassured.response.Response;

public class AddContributorsTest extends BaseTest {

	String sheetName = "AddContributorsTest";
	CreateDossier createDossier;
	AddContributor addContributor;
	String dossierID;

	@BeforeClass
	public void initiateTestName() {
		try {
			init(testScenarioName.get("TS93"), authorName.get("TS93"), moduleName.get("TS93"));
			this.createDossier = new CreateDossier();
			this.addContributor = new AddContributor();
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
		}
	}

	@Test(dataProvider = "getData")
	public void verifySearchDossierTest(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException {

		try {
			Response createDossierResponse = createDossier.createDossier("Dossier Name Goes here");
			int createDossierActualStatusCode = createDossierResponse.getStatusCode();
			String actualCreateDossierResponseBody = createDossier.getPrettifiedResponseBody(createDossierResponse);
			JSONObject jsonObject = new JSONObject(actualCreateDossierResponseBody);
			this.dossierID = jsonObject.get("dossierId").toString();
			if (createDossierActualStatusCode == Integer.parseInt("200")) {
				test.get(0).info("Dossier Created Successfully");
				Response addContributorResponse = addContributor.addContributorForDossier(this.dossierID,
						data.get("Contributors"));
				int addContributorActualStatusCode = addContributorResponse.getStatusCode();
				String requestBodyForAddContributor = AddContributorConstants.getContributors();
				String prettyRequestBodyOfAddContributor = addContributor.toPrettyFormat(requestBodyForAddContributor);

				if (addContributorActualStatusCode == Integer.parseInt(data.get("Expected Status Code"))) {
					test.get(0).info("Test Data Set: " + data.entrySet().toString());
					test.get(0).info(
							"Request Body: " + addContributor.extentReportFormatter(prettyRequestBodyOfAddContributor));
					test.get(0).pass("Actual status code " + addContributorActualStatusCode
							+ " matches with expected status code 204");
					Assert.assertTrue(true);
				} else {
					test.get(0).info("Test Data Set: " + data.entrySet().toString());
					test.get(0).info(
							"Request Body: " + addContributor.extentReportFormatter(prettyRequestBodyOfAddContributor));
					test.get(0).fail("Actual status code " + addContributorActualStatusCode
							+ " does not matches with the expected status code 204");
					Assert.fail();
				}

			} else {
				test.get(0).info("Dossier Creation Failed");
				test.get(0).skip("Skipping This test due to the pre-req dossier creation failed");
			}

		} catch (Exception e) {
			test.get(0).skip("Skipping This test due to exception: " + e);
			// createAnnotation.createBugInJira("Skipped:
			// "+ConsumerIDMissingTest.class.getName(),
			// data.entrySet().toString());
			Assert.fail();
		}

	}

	@DataProvider(name = "getData")
	public Object[][] getData() {
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(
				System.getProperty("user.dir") + "/ExcelFiles/"+prop.getProperty("ENVIRNOMENT")+"/TestData/DossierService/AddContributorTestData.xlsx"),
				sheetName);
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws IOException {

	}

}
