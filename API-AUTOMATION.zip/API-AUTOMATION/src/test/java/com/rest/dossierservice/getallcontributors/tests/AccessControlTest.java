package com.rest.dossierservice.getallcontributors.tests;

public class AccessControlTest {

}
