package com.rest.dossierservice.getdossierdocuments.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rest.base.test.BaseTest;
import com.rest.dossierservice.GetDossierDocuments;
import com.rest.utility.DataUtil;
import com.rest.utility.Xls_Reader;

import io.restassured.response.Response;

public class GetDossierDocumentsTest extends BaseTest{
	
	String sheetName="GetDossierDocumentsTest";
	GetDossierDocuments getDossierDocuments;
	
	@BeforeClass
	public void initiateTestName() 
	{
		try {
			init(testScenarioName.get("TS46"),authorName.get("TS46"),moduleName.get("TS46"));
			this.getDossierDocuments= new GetDossierDocuments();
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
			throw new SkipException ("Skipping Test: @BeforeClass configuration failed");
		}
	}
	
	
	@Test(dataProvider="getData")
	public void verifyGetDossierDocumentsTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
	{
		try {
			ArrayList<String> documentsWhichAreNotPresent= new ArrayList<String>();
			Response response = getDossierDocuments.getDocumentsInsideDossier(data.get("Dossier ID"));
			int actualStatusCode= response.getStatusCode();
			String actualResponseBody = getDossierDocuments.getPrettifiedResponseBody(response);
			boolean isDocumentFoundInDossier=true;
			String[] documentID = data.get("Expected Documents").split(",");
			for(int i=0;i<documentID.length;i++)
			{
				if(!actualResponseBody.contains("documentId\": \"drm_"+documentID[i]))
				{
					isDocumentFoundInDossier=false;
					documentsWhichAreNotPresent.add(documentID[i]);
				}
			}
			if (actualStatusCode==Integer.parseInt(data.get("Expected Status Code")) && isDocumentFoundInDossier==true) 
				{
				test.get(0).info("Test Data Set: "+data.entrySet().toString());
				test.get(0).pass("Actual status code "+actualStatusCode+" matches with expected status code: "+data.get("Expected Status Code") +" and all the expected documents are present in the dossier. "+" \n"+
				getDossierDocuments.extentReportFormatter(actualResponseBody));
				Assert.assertTrue(true);
			} else {
				test.get(0).info("Test Data Set: "+data.entrySet().toString());
				test.get(0).fail("Either status code is not matching or the expected document is not present in the dossier. "+documentsWhichAreNotPresent +" \n"+
				getDossierDocuments.extentReportFormatter(actualResponseBody));
				//createAnnotation.createBugInJira("Failed: "+data.get("FailureTitleInJira")+ConsumerIDMissingTest.class.getName(), data.entrySet().toString());
				Assert.fail();
			} 
		}
		catch (Exception e) {
			test.get(0).skip("Skipping This test due to exception: " + e);
			//createAnnotation.createBugInJira("Skipped: "+ConsumerIDMissingTest.class.getName(), data.entrySet().toString());
			Assert.fail();
		}
	}
	
	@DataProvider(name="getData")
	public Object[][] getData() 
	{
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"/ExcelFiles/"+prop.getProperty("ENVIRNOMENT")+"/TestData/DossierService/GetDossierDocumentsTestData.xlsx"), sheetName);
	}
	
	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		
	}

}
