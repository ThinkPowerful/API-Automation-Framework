package com.rest.dossierservice.getdossiermetadata.tests;

import java.io.IOException;
import java.util.Hashtable;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rest.base.test.BaseTest;
import com.rest.dossierservice.GetDossierMetaData;
import com.rest.utility.DataUtil;
import com.rest.utility.Xls_Reader;

import io.restassured.path.json.exception.JsonPathException;
import io.restassured.response.Response;

/**
 * @author C46630
 *
 */
public class AccessDeniedTest extends BaseTest {

  String sheetName = "AccessDeniedTest";
  GetDossierMetaData getDossierMetaData;
  private JSONArray errorsArray;
  private JSONObject errorObject;



  @BeforeClass
  /**
   * Method to initialize the Test Resource
   */
  public void initiateTestName() {
    try {
      init(testScenarioName.get("TS59"), authorName.get("TS59"), moduleName.get("TS59"));
      this.getDossierMetaData = new GetDossierMetaData();
    } catch (Exception e) {
      test.get(0).skip("@BeforeClass configuration failed");
      throw new SkipException("Skipping Test: @BeforeClass configuration failed");
    }
  }

  @Test(dataProvider = "getData")
  /**
   * Method to verify the Access Denied Scenario
   * @param data
   */
  public void verifyAccessDeniedTest(Hashtable<String, String> data) {
    try {
      Response response = getDossierMetaData.getDossierMetaData(data.get("Dossier ID"));
      String responseBody = getDossierMetaData.getPrettifiedResponseBody(response);
      JSONObject jsonObject = new JSONObject(responseBody);
      this.errorsArray = jsonObject.getJSONArray("errors");
      this.errorObject = errorsArray.getJSONObject(0);
      String message = errorObject.getString("message");
      String status = String.valueOf(errorObject.getInt("status"));
      String code = errorObject.getString("code");
      if (message.equals(data.get("Expected Message")) && code.equals(data.get("Expected Code"))
          && status.equals(data.get("Expected Status"))) {
        test.get(0).info("Test Data Set: " + data.entrySet().toString());
        test.get(0).pass("Response message, status ,code matches as expected" + ", Response Body "
            + getDossierMetaData.extentReportFormatter(responseBody));
        Assert.assertTrue(true);
      } else {
        test.get(0).info("Test Data Set: " + data.entrySet().toString());
        test.get(0).fail("Response message, status ,code does not matches as expected" + ", Response Body "
            + getDossierMetaData.extentReportFormatter(responseBody));
        Assert.fail();
      }
    } catch (JsonPathException e) {
      test.get(0).info("Test Data Set: " + data.entrySet().toString());
      test.get(0).fail("No Response body");
      Assert.fail();
    } catch (Exception e) {
      test.get(0).skip("Skipping This test due to exception: " + e);
      Assert.fail();
    }
  }

  @DataProvider(name = "getData")
  /**
   * Method to Read Test Data from the Resource
   * @return
   */
  public Object[][] getData() {
    return DataUtil.loadDataIntoHashTable(
        new Xls_Reader(
            System.getProperty("user.dir") + "/ExcelFiles/"+prop.getProperty("ENVIRNOMENT")+"/TestData/DossierService/GetDossierMetaDataTestData.xlsx"),
        sheetName);
  }

  @AfterClass(alwaysRun = true)
  public void tearDown() throws IOException {

  }

}
