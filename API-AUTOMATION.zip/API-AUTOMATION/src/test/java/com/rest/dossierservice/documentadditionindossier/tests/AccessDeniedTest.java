package com.rest.dossierservice.documentadditionindossier.tests;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rest.base.test.BaseTest;
import com.rest.dossier.constants.DocumentAdditioninDossierConstants;

import com.rest.dossierservice.DocumentAdditioninDossier;

import com.rest.utility.DataUtil;
import com.rest.utility.Xls_Reader;

import io.restassured.path.json.exception.JsonPathException;
import io.restassured.response.Response;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

public class AccessDeniedTest extends BaseTest {

	String sheetName = "AccessDeniedTest";
	DocumentAdditioninDossier addDocument;
	JSONObject jsonObject;
	JSONObject errorObject;
	JSONArray errorsArray;

	@BeforeClass
	public void initiateTestName() {
		try {
			init(testScenarioName.get("TS160"), authorName.get("TS160"), moduleName.get("TS160"));
			this.addDocument = new DocumentAdditioninDossier();
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
		}
	}

	@Test(dataProvider = "getData")
	public void verifyAccessDeniedTest(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException {

		try {
			Response response = addDocument.reuseDocumentInsideDossier(data.get("Dossier ID"), data.get("Document ID"));
			String requestBody = DocumentAdditioninDossierConstants.getReuseDocumentRequestBody();
			String prettyRequestBody = addDocument.toPrettyFormat(requestBody);
			String actualResponseBody = addDocument.getPrettifiedResponseBody(response);
			JSONObject jsonObject = new JSONObject(actualResponseBody);
			this.errorsArray = jsonObject.getJSONArray("errors");
			this.errorObject = errorsArray.getJSONObject(0);
			String message = errorObject.getString("message");
			String status = String.valueOf(errorObject.getInt("status"));
			String code = errorObject.getString("code");
			if (message.equals(data.get("Expected Message")) && code.equals(data.get("Expected Code"))
					&& status.equals(data.get("Expected Status"))) {
				test.get(0).info("Test Data Set: " + data.entrySet().toString());
				test.get(0).info(addDocument.extentReportFormatter(prettyRequestBody));
				test.get(0).pass("Response message, status ,code matches as expected" + ", Response Body " + " \n"
						+ addDocument.extentReportFormatter(actualResponseBody));
				Assert.assertTrue(true);
			} else {
				test.get(0).info("Test Data Set: " + data.entrySet().toString());
				test.get(0).info(addDocument.extentReportFormatter(prettyRequestBody));
				test.get(0).fail("Response message, status ,code does not matches as expected" + ", Response Body "
						+ addDocument.extentReportFormatter(actualResponseBody));
				Assert.fail();
			}
		} catch (JsonPathException e) {
			test.get(0).info("Test Data Set: " + data.entrySet().toString());
			test.get(0).fail("No Response body");
			Assert.fail();
		} catch (Exception e) {
			test.get(0).skip("Skipping This test due to exception: " + e);
			Assert.fail();
		}

	}

	@DataProvider(name = "getData")
	public Object[][] getData() {
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir") + "/ExcelFiles/"
				+ prop.getProperty("ENVIRNOMENT") + "/TestData/DossierService/DocumentAdditioninDossierTestData.xlsx"),
				sheetName);
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws IOException {

	}

}

