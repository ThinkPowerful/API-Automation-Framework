package com.rest.dossierservice.deleterelatedentities.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rest.base.test.BaseTest;
import com.rest.dossier.constants.DeleteRelatedEntityConstants;
import com.rest.dossierservice.DeleteRelatedEntities;
import com.rest.utility.DataUtil;
import com.rest.utility.Xls_Reader;

import io.restassured.path.json.exception.JsonPathException;
import io.restassured.response.Response;

public class DeleteRelatedEntitiesTest extends BaseTest {
	String sheetName = "DeleteRelatedEntitiesTest";
	DeleteRelatedEntities deleteRelEntity;
	JSONObject jsonObject;
	JSONObject errorObject;
	JSONArray errorsArray;

	@BeforeClass
	public void initiateTestName() {
		try {
			init(testScenarioName.get("TS121"), authorName.get("TS121"), moduleName.get("TS121"));
			this.deleteRelEntity = new DeleteRelatedEntities();
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
		}
	}

	@Test(dataProvider = "getData")
	public void verifyDeleteRelatedEntities(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException {
		 
		try {
			Response response = deleteRelEntity.relatedEntityDeletionWithConsumerID(data.get("Dossier ID"),
					data.get("Related Entity"));
			String requestBody = DeleteRelatedEntityConstants
					.getDeleteRelatedEntityRequestBodyWithMultipleRelatedEntityInfo();
			String prettyRequestBody = deleteRelEntity.toPrettyFormat(requestBody);
			int actualStatusCode = response.getStatusCode();
			if (actualStatusCode == Integer.parseInt(data.get("Expected Status"))) {
				test.get(0).info("Test Data Set: " + data.entrySet().toString());
				test.get(0).info(deleteRelEntity.extentReportFormatter(prettyRequestBody));
				test.get(0).pass("Response Status Code Expected: 204"+", Response Status Code Actual: " + deleteRelEntity.extentReportFormatter(String.valueOf(actualStatusCode)));
				
				Assert.assertTrue(true);
			} else {
				test.get(0).info("Test Data Set: " + data.entrySet().toString());
				test.get(0).info(deleteRelEntity.extentReportFormatter(prettyRequestBody));
				test.get(0).fail("Response Status Code Expected: 204"+", Response Status Code Actual: " + deleteRelEntity.extentReportFormatter(String.valueOf(actualStatusCode)));
				Assert.fail();
			}
		}  catch (Exception e) {
			test.get(0).skip("Skipping This test due to exception: " + e);
			Assert.fail();
		}

	}

	@DataProvider(name = "getData")
	public Object[][] getData() {
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir") + "/ExcelFiles/"
				+ prop.getProperty("ENVIRNOMENT") + "/TestData/DossierService/DeleteRelatedEntitiesTestData.xlsx"),
				sheetName);
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws IOException {

	}

}