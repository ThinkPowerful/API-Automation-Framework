package com.rest.dossierservice.createdossier.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rest.base.test.BaseTest;
import com.rest.dossierservice.CloseDossier;
import com.rest.dossierservice.CreateDossier;
import com.rest.dossierservice.closedossier.tests.ConsumerIDIsMandatoryTest;
import com.rest.utility.DataUtil;
import com.rest.utility.Xls_Reader;

import io.restassured.response.Response;

public class CreateDossierWithDossierNameTest extends BaseTest{
	
	String sheetName="ConsumerIDIsMandatoryTest";
	CreateDossier createDossier;
	JSONObject jsonObject;
	JSONObject errorObject;
	JSONArray errorsArray; 
	
	@BeforeClass
	public void initiateTestName() 
	{
		try {
			init(testScenarioName.get("TS06"),authorName.get("TS06"),moduleName.get("TS06"));
			this.createDossier= new CreateDossier();
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
		}
	}
	
	@Test(dataProvider="getData")
	public void verifyConsumerIDIsMandatoryTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
	{
		createDossier.createDossier("Dossier created From Rest Assuered");
	}
	
	@DataProvider(name="getData")
	public Object[][] getData() 
	{
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"/ExcelFiles/"+prop.getProperty("ENVIRNOMENT")+"/TestData/DossierService/CloseDossierTestData.xlsx"), sheetName);
	}
	
	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		
	}

}
