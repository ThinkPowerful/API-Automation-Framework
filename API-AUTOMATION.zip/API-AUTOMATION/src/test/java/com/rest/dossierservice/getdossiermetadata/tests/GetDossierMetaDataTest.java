package com.rest.dossierservice.getdossiermetadata.tests;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rest.base.test.BaseTest;
import com.rest.dossierservice.GetDossierMetaData;
import com.rest.utility.DataUtil;
import com.rest.utility.Xls_Reader;

import io.restassured.response.Response;

/**
 * @author C46630
 *
 */

public class GetDossierMetaDataTest extends BaseTest {

  GetDossierMetaData getDossierMetaData;
  String sheetName = "GetDossierMetaDataTest";

  @BeforeClass
  /**
   * Method to initialize the Test Resource
   */
  public void initiateTestName() {
    try {
      init(testScenarioName.get("TS61"), authorName.get("TS61"), moduleName.get("TS61"));
      this.getDossierMetaData = new GetDossierMetaData();
    } catch (Exception e) {
      test.get(0).skip("@BeforeClass configuration failed");
      throw new SkipException("Skipping Test: @BeforeClass configuration failed");
    }
  }
  

  @Test(dataProvider = "getData")
  /**
   * Test Method to verify the Dossier Metadata
   * @param data
   */
  public void verifyGetDossierTest(Hashtable<String, String> data) {
    try {
      ArrayList<String> missingDossierMetaData= new ArrayList<String>();
      Response response = getDossierMetaData.getDossierMetaData(data.get("Dossier ID"));
      int actualStatusCode = response.getStatusCode();
      String actualResponseBody = getDossierMetaData.getPrettifiedResponseBody(response);
      boolean isMatch = true;
      String[] documentDossierMetaData = data.get("Expected Metadata").split(",");
      for (int i = 0; i < documentDossierMetaData.length; i++) {
        if (!actualResponseBody.contains("\"" + documentDossierMetaData[i].split(":", 2)[0] + "\"" + ": " + "\""
            + documentDossierMetaData[i].split(":", 2)[1] + "\"")) {
          isMatch = false;
          missingDossierMetaData.add(documentDossierMetaData[i]);
        }
      }
      if (actualStatusCode == Integer.parseInt(data.get("Expected Status")) && isMatch == true) {
        test.get(0).info("Test Data Set: " + data.entrySet().toString());
        test.get(0)
            .pass("Actual status code " + actualStatusCode + " matches with expected status code: "
                + data.get("Expected Status") + " and all the metdata are present in the dossier. " + " \n"
                + getDossierMetaData.extentReportFormatter(actualResponseBody));
        Assert.assertTrue(true);
      } else {
        test.get(0).info("Test Data Set: " + data.entrySet().toString());
        test.get(0).fail("Either status code is not matching or the expected metadata is not present in the dossier. "+ missingDossierMetaData + " \n" +getDossierMetaData.extentReportFormatter(actualResponseBody));
        Assert.fail();
      }

    } catch (Exception e) {
      test.get(0).skip("Skipping This test due to exception: " + e);
      Assert.fail();
    }
  }

  @DataProvider(name = "getData")
  /**
   * Method to Read Test Data from the Resource
   * @return
   */
  public Object[][] getData() {
    return DataUtil.loadDataIntoHashTable(
        new Xls_Reader(
            System.getProperty("user.dir") + "/ExcelFiles/"+prop.getProperty("ENVIRNOMENT")+"/TestData/DossierService/GetDossierMetaDataTestData.xlsx"),
        sheetName);
  }

  @AfterClass(alwaysRun = true)
  public void tearDown() throws IOException {

  }
}
