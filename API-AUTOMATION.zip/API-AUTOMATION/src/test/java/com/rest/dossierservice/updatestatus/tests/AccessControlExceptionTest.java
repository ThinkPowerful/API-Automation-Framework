package com.rest.dossierservice.updatestatus.tests;

public class AccessControlExceptionTest {

}
