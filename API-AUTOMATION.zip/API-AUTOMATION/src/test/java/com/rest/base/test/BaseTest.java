package com.rest.base.test;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.ReportAggregates;
import com.aventstack.extentreports.model.Author;
import com.aventstack.extentreports.model.Test;
import com.rest.reports.ExtentManager;
import com.rest.utility.SMSessionCreator;
import com.rest.utility.Xls_Reader;

public class BaseTest {
	
	public WebDriver driver =null;
	public ExtentReports rep  = ExtentManager.setup();
	public ArrayList<ExtentTest> test =new ArrayList<ExtentTest>();
	public Hashtable<String, String> testScenarioName=new Hashtable<String, String>();
	public Hashtable<String, String> moduleName=new Hashtable<String, String>();
	public Hashtable<String, String> authorName=new Hashtable<String, String>();
	public Properties prop = new Properties();
	public InputStream input = null;
	
	@BeforeSuite
	public void setCookie() throws IOException
	{
		//XmlGenerator.generateXML();
		//String smSessionCookie = SMSessionCreator.employeeSession("S03537", "testen#1", "launchert","ST");
		InputStream in = new FileInputStream(System.getProperty("user.dir")+"/Properties/config.properties");
		prop.load(in);
		String smSessionCookie = SMSessionCreator.employeeSession(prop.get("USERNAME").toString(), prop.get("PASSWORD").toString(), prop.get("DOMAIN").toString(),prop.get("ENVIRNOMENT").toString());
		prop.setProperty("SESSION", smSessionCookie);
		prop.store(new FileOutputStream(System.getProperty("user.dir")+"/Properties/config.properties"), null);
	}
	
	@BeforeTest
	public void doSetup() throws IOException
	{
		
		Xls_Reader xls =new Xls_Reader(System.getProperty("user.dir")+"/ExcelFiles/TestSuite/TestSuite.xlsx");
		int rCount = xls.getRowCount("TestCases");
	
		for(int rNum=2;rNum<=rCount;rNum++)
		{
			testScenarioName.put(xls.getCellData("TestCases", 0, rNum),xls.getCellData("TestCases", 1, rNum));
			moduleName.put(xls.getCellData("TestCases", 0, rNum),xls.getCellData("TestCases", 2, rNum));
			authorName.put(xls.getCellData("TestCases", 0, rNum),xls.getCellData("TestCases", 3, rNum));
		}
	}
	
	public void init(String testName, String author, String testCategory) throws IOException
	{
		System.getProperties().put("http.proxyHost", "nl-proxy-access.net.abnamro.com");
		System.getProperties().put("http.proxyPort", "8080");
		System.getProperties().put("https.proxyHost", "nl-proxy-access.net.abnamro.com");
		System.getProperties().put("https.proxyPort", "8080");
		/*System.getProperties().put("http.proxyHost", "nl-userproxy-access.net.abnamro.com");
		System.getProperties().put("http.proxyPort", "8080");
		System.getProperties().put("https.proxyHost", "nl-userproxy-access.net.abnamro.com");
		System.getProperties().put("https.proxyPort", "8080");*/
		test.add(rep.createTest(testName));
		Test test1 = new Test();
		test1.setName(testName);
		test.get(0).assignAuthor(author);
		test.get(0).assignCategory(testCategory);
		input = new FileInputStream(System.getProperty("user.dir")+"/Properties/config.properties");
		prop.load(input);
	}
	
	
	@AfterSuite(alwaysRun=true)
	public void flushReport() throws IOException
	{
		rep.flush();
	}

}
