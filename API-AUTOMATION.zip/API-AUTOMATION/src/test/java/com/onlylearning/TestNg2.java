package com.onlylearning;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import org.json.JSONObject;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.rest.dossier.constants.AddContributorConstants;

public class TestNg2 extends BaseTestNG
{
	
	
	@Test
	public void test1() throws IOException
	{
		setContributors("S03297;S03300");
    }
	

	public static void setContributors(String contributors) {
		JSONObject temp;
		JSONObject addContributors = new JSONObject();
		temp = contributors != "" ? addContributors.put("contributorIds", setArray(contributors))
				: null;
		AddContributorConstants.contributor=addContributors.toString();
		System.out.println(addContributors);
	}
	
	public static String[] setArray(String values) {
		return values.split(";");
	}
		
}
