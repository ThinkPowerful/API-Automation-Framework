package com.onlylearning;

public class TextInput {
	
	 String value;
	 StringBuilder builder= new StringBuilder();
     
     public void add(char c)
     {
    	 if(Character.isDigit(c))
    	 {
         value=builder.append(c).toString();
    	 }
     }
     
     public String getValue()
     {
         return value;
     }

}
