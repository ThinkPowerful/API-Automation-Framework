/**
 * 
 */
package com.onlylearning;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.annotations.JsonAdapter;

/**
 * @author C47273
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class RestResponseObject {
	private List<ErrorObject> errors;

	/**
	 * @return the errors
	 */
	public List<ErrorObject> getErrors() {
		return errors;
	}

	/**
	 * @param errors
	 *            the errors to set
	 */
	public void setErrors(List<ErrorObject> errors) {
		this.errors = errors;
	}

}
