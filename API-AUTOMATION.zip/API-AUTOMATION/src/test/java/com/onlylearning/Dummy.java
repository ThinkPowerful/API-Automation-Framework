package com.onlylearning;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import com.rest.utility.DateUtil;

public class Dummy {
	
	static StringBuilder requestBody= new StringBuilder();
	static String commoTruncated;
	
	public static void main(String[] args) throws ParseException {
		/*String relatedEntityInfo= "adminID1-Type1-Value1,adminID2-Type2-Value2";
		List<String> relatedEntityTriplet = new ArrayList<String>();
		String[] relatedEntitySplitOnCommo = relatedEntityInfo.split(",");
		for(int i=0; i<relatedEntitySplitOnCommo.length;i++)
		{
			String[] relatedEntitySplitOnHyphen = relatedEntitySplitOnCommo[i].split("-");
			requestBody.append("{\"searchRelatedEntityInfo\":{\"administrationId\":\""+relatedEntitySplitOnHyphen[0]+"\",\"type\":\""+relatedEntitySplitOnHyphen[1]+"\",\"id\":\""+relatedEntitySplitOnHyphen[2]+"\"}},");
			commoTruncated = requestBody.substring(0, requestBody.length()-1);
		}*/
		DateUtil.convertDateToString(DateUtil.getCurrentdateInYearMonthDate());
		
	
		System.out.println(	DateUtil.convertDateToStringInYearMonthDate(DateUtil.getCurrentdateInYearMonthDate()));
		
	}
	
}
