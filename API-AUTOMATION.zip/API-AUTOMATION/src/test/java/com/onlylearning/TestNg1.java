package com.onlylearning;

import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TestNg1 extends BaseTestNG
{
	
	
	
	@BeforeClass
	public void beforeClass()
	{
		try {
			System.out.println("Before Class in TestNG 1");
			init("testNG1","testNG1","testNG1");
			throw new Exception();
		} catch (Exception e) {
			test.get(0).skip("report generated");
			throw new SkipException ("Skipping Test: ");
		}
	}
	
	@Test
	public void test1()
	{
		System.out.println("Test1");
		test.get(0).pass("report generated");
	}
	
	@AfterClass
	public void afterClass()
	{
		System.out.println("After Class in TestNG 1");
	}
	
	
	
}
