package com.onlylearning;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.rest.base.test.BaseTest;
import com.rest.baseservice.BaseOperation;

public class FirstClassRestAssured extends BaseTest
{
	
	BaseOperation bs;
	
	@BeforeTest
	public void beforeTest() throws IOException
	{
		init("test1","catogory1","author2");
		this.bs=new BaseOperation();
	}
	
	@Test
    public void test1() throws IOException {
		bs.createBugInJira("test1","test1");
	}
	
	@Test
    public void test2() throws IOException {
		bs.createBugInJira("test2","test2");
	}
	
	

}
