package com.onlylearning;

import java.util.Date;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentManagerDummy {

	static ExtentHtmlReporter htmlReporter;
	static ExtentReports extent;
	public static ExtentReports setup() 
	{
		if (extent == null) 
		{
			Date d=new Date();
			//String fileName=d.toString().replace(":", "_").replace(" ", "_")+".html";
			String fileName="DummyReport.html";
			extent = new ExtentReports();
			htmlReporter =  new ExtentHtmlReporter("C:\\Users\\C47273\\Xen Desktop\\Crucial\\workspace\\restautomation\\ExtentReports\\"+fileName);
			extent.attachReporter(htmlReporter);
			htmlReporter.config().setReportName("Regression Testing");
			htmlReporter.config().setTheme(Theme.STANDARD);
		}
		return extent;
	}

}
