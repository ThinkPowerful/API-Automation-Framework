package com.onlylearning;

import java.util.List;

public class ErrorObject {

	public static boolean isPalindrome(String word) {
	       
        StringBuilder input1 = new StringBuilder();
        input1= input1.append(word);
        String input3=input1.toString().toLowerCase();
        StringBuilder input2 = new StringBuilder();
        input2= input1.reverse();
        String input4 = input2.toString().toLowerCase();
		/*String input1="Deleveled";
		String input2="Deleveled";*/
		
        if(input3.equals(input4))
        {
            return true;
        }else
        {
            return false;
        }
    }
    
    public static void main(String[] args) {
        System.out.println(ErrorObject.isPalindrome("San"));
    }
}
