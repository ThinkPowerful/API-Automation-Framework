package com.rest.baseservice;

import static io.restassured.RestAssured.given;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.util.Properties;
import java.util.zip.ZipFile;

import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class BaseOperation {

	public Properties prop = new Properties();
	public InputStream input = null;
	public String jiraSessionID = null;

	public BaseOperation() throws IOException {
		input = new FileInputStream(System.getProperty("user.dir") + "/Properties/config.properties");
		prop.load(input);
		RestAssured.baseURI = prop.getProperty("BASEURI");
	}

	public String extentReportFormatter(String reportLog) {
		return "<pre>" + reportLog + "</pre>";
	}

	public int getResponseStatusCode(Response res) {
		return res.getStatusCode();
	}

	public String getPrettifiedResponseBody(Response res) {
		Response rawResponse = res.then().extract().response();
		JsonPath JsonFormatedResponse = Utility.rawToJSON(rawResponse);
		return JsonFormatedResponse.prettify();
	}
	
	public String toPrettyFormat(String jsonString) 
	  {
	      JsonParser parser = new JsonParser();
	      JsonObject json = parser.parse(jsonString).getAsJsonObject();
	      Gson gson = new GsonBuilder().setPrettyPrinting().create();
	      String prettyJson = gson.toJson(json);
	      return prettyJson;
	  }
	
	public String readContentFromJsonFile(String jsonFilePath) throws IOException, ParseException
	{
		JSONParser jsonParser = new JSONParser();
		FileReader reader = new FileReader(jsonFilePath);
		Object obj = jsonParser.parse(reader);
		return obj.toString();
	}
	
	public Response createBugInJira(String summary, String description){
		RestAssured.baseURI = prop.getProperty("JIRABASEURI");
		Response res = given().header("Authorization", "Basic QzQ3MjczOkluZGlhbmlkb2xANQ==")
				.header("Content-Type", "application/json")
				.body(JiraRequestPayload.createIssue(prop.getProperty("JIRATASKID"), summary, description)).when()
				.post("/rest/api/2/issue/");
		System.out.println(res.statusCode());
		return res;
	}

	public String establishSession() {
		Response res = given().header("Content-Type", "application/json")
				.body("{ \"username\": \"C47273\", \"password\": \"Indianidol@5\" }").when()
				.post("/rest/auth/1/session").then().statusCode(200).extract().response();
		JsonPath JsonFormatedResponse = Utility.rawToJSON(res);
		this.jiraSessionID = JsonFormatedResponse.get("session.value");
		return this.jiraSessionID;
	}

	public static void downloadLocally(byte[] file, String fileName, String fileFormat) {
		FileOutputStream fos;
		try {
			fos = new FileOutputStream(
					System.getProperty("user.dir") + "/ExtentReports/Downloads/" + fileName + "." + fileFormat);
			fos.write(file);
			fos.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static boolean isFileSuccessfullyDownloaded(String fileName, String fileFormat) throws InterruptedException {
		Thread.sleep(2000);
		File downloadedZipFile = new File(
				System.getProperty("user.dir") + "/ExtentReports/Downloads/" + fileName + "." + fileFormat);
		if (downloadedZipFile.exists()) {
			return true;
		} else {
			return false;
		}
	}

	public static String getFileSizeInMb(String fileName, String fileFormat) {
		File downloadedFile = new File(
				System.getProperty("user.dir") + "/ExtentReports/Downloads/" + fileName + "." + fileFormat);
		return String.valueOf((downloadedFile.length()/1024)/1024);
	}

	public static boolean validateCountInZipFile(String fileName, String numberOfFiles) throws Exception {

		int numberOfFilesInInt = Integer.parseInt(numberOfFiles);
		Path pathToFile = FileSystems.getDefault()
				.getPath(System.getProperty("user.dir") + "/ExtentReports/Downloads/" + fileName + ".zip");
		ZipFile zipFile = new ZipFile(pathToFile.toFile());

		if (zipFile.size() == numberOfFilesInInt) {
			return true;
		} else {
			return false;
		}
	}

}
