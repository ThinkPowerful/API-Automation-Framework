package com.rest.dossierservice;

import static io.restassured.RestAssured.given;

import java.io.IOException;

import com.rest.baseservice.BaseOperation;
import com.rest.dossier.constants.CreateDIDAnnotationConstants;

import io.restassured.response.Response;

public class CreateDIDAnnotation extends BaseOperation{
	
	public CreateDIDAnnotation() throws IOException {
		super();
	}

	public Response createAnnotationForDocumentsInsideDossier(String dossierID, String documentID, String annotationText)
	{
		CreateDIDAnnotationConstants.setAnnotation(annotationText);
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit").keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header("Content-Type", prop.get("Content-Type")).cookie("SMSESSION", prop.getProperty("SESSION")).body(CreateDIDAnnotationConstants.getAnnotation()).
					when().post(prop.getProperty("BASEURI")+"/rest/api/v2/dossiers/"+dossierID+"/annotations/did/drm:"+documentID+"/annotations");
		return res;
	}
	
	public Response createAnnotationForDocumentsInsideDossierWithoutConsumerID(String dossierID, String documentID, String annotationText)
	{
		CreateDIDAnnotationConstants.setAnnotation(annotationText);
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit").keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header("Content-Type", prop.get("Content-Type")).cookie("SMSESSION", " ").body(CreateDIDAnnotationConstants.getAnnotation()).
					when().post(prop.getProperty("BASEURI")+"/rest/api/v2/dossiers/"+dossierID+"/annotations/did/drm:"+documentID+"/annotations");
		return res;
	}

}
