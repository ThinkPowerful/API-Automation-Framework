package com.rest.dossierservice;

import static io.restassured.RestAssured.given;
import java.io.IOException;

import com.rest.baseservice.BaseOperation;
import com.rest.dossier.constants.DeleteRelatedEntityConstants;
import io.restassured.response.Response;

public class DeleteRelatedEntities extends BaseOperation {

	public DeleteRelatedEntities() throws IOException {
		super();
	}

	public Response relatedEntityDeletionWithConsumerID(String dossierId, String relatedEntityTriplet)
			throws InterruptedException {

		DeleteRelatedEntityConstants
				.setDeleteRelatedEntityRequestBodyWithMultipleRelatedEntityInfo(relatedEntityTriplet);
		String body = DeleteRelatedEntityConstants.getDeleteRelatedEntityRequestBodyWithMultipleRelatedEntityInfo();
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit").keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header("Content-Type", prop.get("Content-Type"))
				.header("Consumer-Id", prop.get("CONSUMERID")).body(body).when()
				.post(prop.getProperty("BASEURI") + "/rest/api/v2/dossiers/" + dossierId + "/relatedentitiesdeletion");
		return res;

	}

	public Response relatedEntityDeletionWithoutConsumerID(String dossierID, String relatedEntityTriplet) {
		DeleteRelatedEntityConstants
				.setDeleteRelatedEntityRequestBodyWithMultipleRelatedEntityInfo(relatedEntityTriplet);
		String body = DeleteRelatedEntityConstants.getDeleteRelatedEntityRequestBodyWithMultipleRelatedEntityInfo();
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit").keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header("Content-Type", prop.get("Content-Type")).body(body).when()
				.post(prop.getProperty("BASEURI") + "/rest/api/v2/dossiers/" + dossierID + "/relatedentitiesdeletion");
		return res;
	}

}
