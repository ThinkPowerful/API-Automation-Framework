package com.rest.dossierservice;

import static io.restassured.RestAssured.given;

import java.io.IOException;

import com.rest.baseservice.BaseOperation;

import com.rest.dossier.constants.UpdateDossierConstants;

import io.restassured.response.Response;

public class UpdateDossier extends BaseOperation {

	public UpdateDossier() throws IOException {
		super();
	}

	public Response updateDossierWithMandatoryAndOptionalParameters(String dossierId, String sourceId,
			String creationDateTime, String creatorConsumerId, String lastModifierUserId, String lastModifiedTimestamp,
			String title, String description, String sourceLabel, String accessType, String securityLevel,
			String dossierName, String dossierType, String status, String relatedEntity, String contextInfo,
			String scopeInfo, String actionslist, String retention, String rating) throws InterruptedException {

		UpdateDossierConstants.setUpdateDossierRequestBody(dossierId, sourceId, creationDateTime, creatorConsumerId,
				lastModifierUserId, lastModifiedTimestamp, title, description, sourceLabel, accessType, securityLevel,
				dossierName, dossierType, status, relatedEntity, contextInfo, scopeInfo, actionslist, retention,
				rating);
		String body = UpdateDossierConstants.getUpdateDossierRequestBody();
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit").keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header("Content-Type", prop.get("Content-Type"))
				.cookie("SMSESSION", prop.getProperty("SESSION")).body(body).when()
				.put(prop.getProperty("BASEURI") + "/rest/api/v2/dossiers/" + dossierId);
		return res;
	}

}
