package com.rest.dossierservice;

import static io.restassured.RestAssured.given;

import java.io.IOException;

import com.rest.baseservice.BaseOperation;

import io.restassured.response.Response;

public class GetAllContributor extends BaseOperation{
	
	public GetAllContributor() throws IOException {
		super();
	}

	public Response getAllContributorsOfDossier(String dossierID)
	{
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit").keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header("Content-Type", prop.get("Content-Type")).cookie("SMSESSION", prop.getProperty("SESSION")).
					when().get(prop.getProperty("BASEURI")+"/rest/api/v2/dossiers/"+dossierID+"/contributors");
		return res;
	}

}
