package com.rest.dossierservice;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.rest.baseservice.BaseOperation;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class UpdateStatus extends BaseOperation{
	
	public UpdateStatus() throws IOException
	{
		super();
	}
	
	public Response updateDossierStatus(String dossierID, String status)
	{
		System.out.println(prop.getProperty("BASEURI")+"/rest/api/v1/dossiers/"+dossierID+"/status");
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit").keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header("Content-Type", prop.get("Content-Type")).cookie("SMSESSION", prop.getProperty("SESSION")).body("{\"dossierLifeCycleStatus\":\""+status+"\"}").
					when().post(prop.getProperty("BASEURI")+"/rest/api/v1/dossiers/"+dossierID+"/status");
		System.out.println(res.getStatusCode());
		System.out.println(res.getBody().toString());
		return res;
	}

}
