package com.rest.dossierservice;

import static io.restassured.RestAssured.given;

import java.io.IOException;

import com.rest.baseservice.BaseOperation;

import com.rest.dossier.constants.DocumentAdditioninDossierConstants;

import io.restassured.response.Response;

public class DocumentAdditioninDossier extends BaseOperation{

	public DocumentAdditioninDossier() throws IOException {
		super();
	}

	public Response reuseDocumentInsideDossier(String dossierID, String documentID)
	{
		DocumentAdditioninDossierConstants.setReuseDocumentRequestBody(documentID);
		String body = DocumentAdditioninDossierConstants.getReuseDocumentRequestBody();
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit").keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header("Content-Type", prop.get("Content-Type"))
				.header("Consumer-Id", prop.get("CONSUMERID")).body(body).when()
				.post(prop.getProperty("BASEURI") + "/rest/api/v2/dossiers/" + dossierID + "/documentsaddition");
		return res;
	
	}
	public Response reuseDocumentInsideDossierwithoutConsumerID(String dossierID, String documentID)
	{
		DocumentAdditioninDossierConstants.setReuseDocumentRequestBody(documentID);
		String body = DocumentAdditioninDossierConstants.getReuseDocumentRequestBody();
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit").keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header("Content-Type", prop.get("Content-Type"))
				.body(body).when().post(prop.getProperty("BASEURI") + "/rest/api/v2/dossiers/" + dossierID + "/documentsaddition");
		return res;
	
	}
	
	
}

