package com.rest.dossierservice;

import static io.restassured.RestAssured.given;

import java.io.IOException;

import com.rest.baseservice.BaseOperation;
import com.rest.dossier.constants.CreateDossierConstants;
import com.rest.dossier.constants.SearchDossierConstants;

import io.restassured.response.Response;

public class SearchDossier extends BaseOperation {

	public SearchDossier() throws IOException {
		super();
	}

	public Response SearchDossierWithAllParameters(String searchConditionType, String relatedEntities,
			String dossierName, String creationDate, String pageNumber, String pageSize, String lastModifiedDate,
			String creatorConsumerId, String lastModifierUserId, String sourceId, String sortBy, String description)
			throws InterruptedException {
		Thread.sleep(2000);
		SearchDossierConstants.setSearchDossierRequestBodyWithAllParameters(searchConditionType, relatedEntities,
				dossierName, creationDate, pageNumber, pageSize, lastModifiedDate, creatorConsumerId,
				lastModifierUserId, sourceId, sortBy, description);
		String body = SearchDossierConstants.getSearchDossierRequestBodyWithAllParameters();
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit")
				.keyStore("certs/certificate_pkey_new.jks", "esb-et-test")
				.header("Content-Type", prop.get("Content-Type")).cookie("SMSESSION", prop.getProperty("SESSION"))
				.body(body).when().post(prop.getProperty("BASEURI") + "/rest/api/v2/dossiers/search");
		return res;

	}

}
