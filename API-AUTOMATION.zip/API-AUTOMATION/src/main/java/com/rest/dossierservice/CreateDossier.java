package com.rest.dossierservice;

import static io.restassured.RestAssured.given;

import java.io.IOException;

import com.rest.baseservice.BaseOperation;
import com.rest.dossier.constants.CreateDossierConstants;

import io.restassured.response.Response;

public class CreateDossier extends BaseOperation{

	public CreateDossier() throws IOException
	{
		super();
	}
	
	public Response createDossier(String dossierName) throws InterruptedException
	{
		CreateDossierConstants.setCreateDossierOnlyWithDossierName(dossierName);
		String body = CreateDossierConstants.getCreateDossierOnlyWithDossierName();
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit").keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header("Content-Type", prop.get("Content-Type")).cookie("SMSESSION", prop.getProperty("SESSION")).body(body).
					when().post(prop.getProperty("BASEURI")+"/rest/api/v2/dossiers");
		return res;
	}
	
	public Response createDossierWithoutConsumerID(String dossierName) throws InterruptedException
	{
		CreateDossierConstants.setCreateDossierOnlyWithDossierName(dossierName);
		String body = CreateDossierConstants.getCreateDossierOnlyWithDossierName();
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit").keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header("Content-Type", prop.get("Content-Type")).body(body).
					when().post(prop.getProperty("BASEURI")+"/rest/api/v2/dossiers");
		return res;
	}
	
	public Response createDossierWithMandatoryAndOptionalParameters(String dossierName,String title, String description, String sourceID, String sourceLabel, String relatedEntityAdministrationID, String relatedEntityId, String relatedEntityType,
			String retentionPeriod, String retentionStartDateTime, String retentionEndDateTime, String scopeAdministrationID, String scopeType, String scopeValue,
			String securityLevel, String confidentialityRating, String integrityRating, String availabilityRating, String securityClassifier, String dossierType, String dossierContextsValue, String dossierContextType, String dossierContextAdmin) throws InterruptedException {
		
		CreateDossierConstants.setCreateDossierRequestBodyWithAllParameters(dossierName,title,description,sourceID,sourceLabel,relatedEntityAdministrationID,relatedEntityId, relatedEntityType,
				retentionPeriod, retentionStartDateTime, retentionEndDateTime, scopeAdministrationID, scopeType, scopeValue,
				securityLevel, confidentialityRating, integrityRating,  availabilityRating, securityClassifier,  dossierType,  dossierContextsValue,dossierContextType,dossierContextAdmin);
		String body = CreateDossierConstants.getCreateDossierRequestBodyWithAllParameters();
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit").keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header("Content-Type", prop.get("Content-Type")).cookie("SMSESSION", prop.getProperty("SESSION")).body(body).
					when().post(prop.getProperty("BASEURI")+"/rest/api/v2/dossiers");
		return res;
	}
	
	public Response createDossierWithMultipleRelatedEntityInfo(String dossierName,String title, String description, String sourceID, String sourceLabel, String relatedEntityTriplet,
			String retentionPeriod, String retentionStartDateTime, String retentionEndDateTime, String scopeAdministrationID, String scopeType, String scopeValue,
			String securityLevel, String confidentialityRating, String integrityRating, String availabilityRating, String securityClassifier, String dossierType, String dossierContextsValue, String dossierContextType, String dossierContextAdmin) throws InterruptedException {
		
		CreateDossierConstants.setCreateDossierRequestBodyWithMultipleRelatedEntityInfo(dossierName,title,description,sourceID,sourceLabel,relatedEntityTriplet,
				retentionPeriod, retentionStartDateTime, retentionEndDateTime, scopeAdministrationID, scopeType, scopeValue,
				securityLevel, confidentialityRating, integrityRating,  availabilityRating, securityClassifier,  dossierType,  dossierContextsValue,dossierContextType,dossierContextAdmin);
		String body = CreateDossierConstants.getCreateDossierRequestBodyWithMultipleRelatedEntityInfo();
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit").keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header("Content-Type", prop.get("Content-Type")).cookie("SMSESSION", prop.getProperty("SESSION")).body(body).
					when().post(prop.getProperty("BASEURI")+"/rest/api/v2/dossiers");
		return res;
	}
	
}
