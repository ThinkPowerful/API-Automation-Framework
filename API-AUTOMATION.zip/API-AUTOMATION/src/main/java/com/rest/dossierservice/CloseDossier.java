package com.rest.dossierservice;

import static io.restassured.RestAssured.given;

import java.io.IOException;

import com.rest.baseservice.BaseOperation;

import io.restassured.response.Response;

public class CloseDossier extends BaseOperation{

	public CloseDossier() throws IOException
	{
		super();
	}
	
	public Response closeDossier(String dossierID, String status)
	{
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit").keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header("Content-Type", prop.get("Content-Type")).cookie("SMSESSION", prop.getProperty("SESSION")).
					when().post(prop.getProperty("BASEURI")+"/rest/api/v2/dossiers/"+dossierID+"/"+status);
		//System.out.println(getPrettifiedResponseBody(res));
		return res;
	}
	
	public Response closeDossierWithoutConsumerID(String dossierID, String status)
	{
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit").keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header("Content-Type", prop.get("Content-Type")).
					when().post(prop.getProperty("BASEURI")+"/rest/api/v2/dossiers/"+dossierID+"/"+status);
		return res;
	}
	
	public Response closeDossierWithConsumerID(String dossierID, String status)
	{
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit").keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header("Content-Type", prop.get("Content-Type")).header("consumer-id",prop.getProperty("CONSUMERID")).
					when().post(prop.getProperty("BASEURI")+"/rest/api/v2/dossiers/"+dossierID+"/"+status);
		return res;
	}
}
