package com.rest.reports;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Date;
import java.util.Properties;
import org.apache.log4j.Logger;
import java.text.SimpleDateFormat;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;


public class ExtentManager {

	static ExtentHtmlReporter htmlReporter;
	static ExtentReports extent;
	static Properties prop = new Properties();
	static Properties log4jProp = new Properties();
	static InputStream input = null;
	static InputStream log4JProperties = null;
	public static final String REPORT_FILE_PATH = System.getProperty("user.dir")+"/ExtentReports/";
	
	public static ExtentReports setup() 
	{
		if (extent == null) 
		{
			try {
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
				System.setProperty("CURRENT_TIME", dateFormat.format(new Date()));
				System.setProperty("RELATIVE_PATH", System.getProperty("user.dir")+"\\ExtentReports");
				input = new FileInputStream(System.getProperty("user.dir")+"/Properties/config.properties");
				log4JProperties = new FileInputStream(System.getProperty("user.dir")+"\\src\\main\\resources\\log4j.properties");
				log4jProp.load(log4JProperties);
				log4jProp.setProperty("log", "RELATIVE_PATH");
				Logger log = Logger.getLogger(ExtentManager.class.getName());
				prop.load(input);
				prop.setProperty("ENVIRNOMENT",System.getProperty("ENVIRNOMENT"));
				prop.setProperty("BASEURI",System.getProperty("BASEURI"));
				prop.setProperty("DOMAIN",System.getProperty("DOMAIN"));
				prop.setProperty("USERNAME",System.getProperty("USERNAME"));
				prop.setProperty("PASSWORD",System.getProperty("PASSWORD"));
				prop.setProperty("RELEASE_TEAM_BRANCH",System.getProperty("RELEASE_TEAM_BRANCH"));
				prop.setProperty("CONSUMERID",System.getProperty("CONSUMERID"));
				prop.store(new FileOutputStream(System.getProperty("user.dir")+"/Properties/config.properties"), null);
				log.info("Environment: "+prop.getProperty("ENVIRNOMENT"));
				log.info("Application URL: "+prop.getProperty("BASEURI"));
				log.info("Domain URL: "+prop.getProperty("DOMAIN"));
				log.info("Username: "+prop.getProperty("USERNAME"));
				log.info("Password: "+prop.getProperty("PASSWORD"));
				log.info("Release Team and Branch: "+prop.getProperty("RELEASE_TEAM_BRANCH"));
				log.info("Technical User: "+prop.getProperty("CONSUMERID"));

			} catch (Exception e) {
				e.printStackTrace();
			}
			Date d=new Date();
			String fileName=prop.getProperty("ENVIRNOMENT")+"_"+d.toString().replace(":", "_").replace(" ", "_")+".html";
			extent = new ExtentReports();
			htmlReporter =  new ExtentHtmlReporter(REPORT_FILE_PATH+fileName);
			extent.attachReporter(htmlReporter);
			htmlReporter.config().setReportName("Regression testing executed in: "+prop.getProperty("ENVIRNOMENT")+" - "+prop.getProperty("BASEURI"));
			htmlReporter.config().setTheme(Theme.STANDARD);
		}
		return extent;
	}

}
