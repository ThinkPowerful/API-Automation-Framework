package com.rest.dossier.constants;

public class DocumentAdditioninDossierConstants {
	
public static String documentID;
	
	public static void setReuseDocumentRequestBody(String documentids) {
		
		DocumentAdditioninDossierConstants.documentID="{\"documentIds\": [ \""+documentids+"\"]}";

	}
	
	public static String getReuseDocumentRequestBody() {
		return documentID;
	}
}
