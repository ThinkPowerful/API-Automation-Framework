package com.rest.dossier.constants;

public class CreateDIDAnnotationConstants {

	
	public static String annotation;
	
	public static void setAnnotation(String annotationText) {
		
		CreateDIDAnnotationConstants.annotation="{\"annotation\": {\"text\": \""+annotationText+"\"}}";

	}
	
	public static String getAnnotation() {
		return annotation;
	}

}
