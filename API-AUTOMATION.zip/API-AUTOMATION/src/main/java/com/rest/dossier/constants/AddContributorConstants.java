package com.rest.dossier.constants;

import org.json.JSONObject;

import com.rest.baseconstant.BaseConstants;

public class AddContributorConstants extends BaseConstants{
	
public static String contributor;
	
	public static void setContributors(String contributors) {
		@SuppressWarnings("unused")
		JSONObject temp;
		JSONObject addContributors = new JSONObject();
		temp = contributors != "" ? addContributors.put("contributorIds", setArray(contributors))
				: null;
		AddContributorConstants.contributor=addContributors.toString();
	}
	
	public static String getContributors() {
		return contributor;
	}

}
