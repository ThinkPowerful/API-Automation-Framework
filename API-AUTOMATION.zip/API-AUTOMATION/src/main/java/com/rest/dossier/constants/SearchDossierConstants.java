package com.rest.dossier.constants;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;
import org.testng.annotations.Test;

public class SearchDossierConstants {
	public static String SearchDossierRequestBodyWithAllParameters;

	public static void setSearchDossierRequestBodyWithAllParameters(String searchConditionType, String relatedEntities,
			String dossierName, String creationDate, String pageNumber, String pageSize, String lastModifiedDate,
			String creatorConsumerId, String lastModifierUserId, String sourceId, String sortBy, String description) {
		JSONObject temp;
		JSONObject searchDossierRequestJson = new JSONObject();
		temp = searchConditionType != "" ? searchDossierRequestJson.put("searchConditionType", searchConditionType)
				: null;
		temp = relatedEntities != ""
				? searchDossierRequestJson.put("relatedEntities", setMultipleInfoIntoArray(relatedEntities)) : null;
		JSONObject searchDossierRelatedEntity = new JSONObject();
		searchDossierRelatedEntity.put("relatedEntitySearchCriteria", searchDossierRequestJson);
		temp = dossierName != "" ? searchDossierRelatedEntity.put("dossierName", setObject(dossierName)) : null;
		temp = creationDate != "" ? searchDossierRelatedEntity.put("creationDate", setObject(creationDate)) : null;
		temp = pageNumber != "" ? searchDossierRelatedEntity.put("pageNumber", pageNumber) : null;
		temp = pageSize != "" ? searchDossierRelatedEntity.put("pageSize", pageSize) : null;
		temp = lastModifiedDate != "" ? searchDossierRelatedEntity.put("lastModifiedDate", setObject(lastModifiedDate))
				: null;
		temp = creatorConsumerId != "" ? searchDossierRelatedEntity.put("creatorConsumerId", creatorConsumerId) : null;
		temp = lastModifierUserId != "" ? searchDossierRelatedEntity.put("lastModifierUserId", lastModifierUserId)
				: null;
		temp = sourceId != "" ? searchDossierRelatedEntity.put("sourceId", sourceId) : null;
		temp = sortBy != "" ? searchDossierRelatedEntity.put("sortBy", sortBy) : null;
		temp = description != "" ? searchDossierRelatedEntity.put("description", setObject(description)) : null;
		SearchDossierRequestBodyWithAllParameters = searchDossierRelatedEntity.toString();
	}

	public static String getSearchDossierRequestBodyWithAllParameters() {
		return SearchDossierRequestBodyWithAllParameters;
	}

	public static List<Map<String, String>> setMultipleInfoIntoArray(String value) {
		String[] eachObject = value.split(";");
		List<Map<String, String>> tripletArray = new ArrayList<Map<String, String>>();
		for (int i = 0; i < eachObject.length; i++) {
			String[] eachKeyVal = eachObject[i].split("-");
			Map<String, String> keyVal = new HashMap<String, String>();

			for (int j = 0; j < eachKeyVal.length; j++) {
				keyVal.put(eachKeyVal[j].substring(0, eachKeyVal[j].indexOf("=")),
						eachKeyVal[j].substring(eachKeyVal[j].indexOf("=") + 1));
			}
			tripletArray.add(keyVal);
		}
		return tripletArray;
	}

	public static Map<String, String> setObject(String tripletInfo) {
		String[] eachTriplet = tripletInfo.split(",");
		Map<String, String> keyVal = new HashMap<String, String>();
		for (int j = 0; j < eachTriplet.length; j++) {
			keyVal.put(eachTriplet[j].substring(0, eachTriplet[j].indexOf("=")),
					eachTriplet[j].substring(eachTriplet[j].indexOf("=") + 1));
		}
		return keyVal;
	}

}
