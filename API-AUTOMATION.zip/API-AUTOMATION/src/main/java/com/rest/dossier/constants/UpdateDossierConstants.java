package com.rest.dossier.constants;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONObject;

public class UpdateDossierConstants {

	public static String updateDossierRequestBody;

	public static void setUpdateDossierRequestBody(String dossierId, String sourceId, String creationDateTime,
			String creatorConsumerId, String lastModifierUserId, String lastModifiedTimestamp, String title,
			String description, String sourceLabel, String accessType, String securityLevel, String dossierName,
			String dossierType, String status, String relatedEntities, String dossierContexts, String scopes,
			String actionslist, String retention, String rating) {

		JSONObject temp;
		JSONObject updateDossierRequestJson = new JSONObject();
		temp = sourceId != "" ? updateDossierRequestJson.put("sourceId", sourceId) : null;
		temp = lastModifiedTimestamp != ""
				? updateDossierRequestJson.put("lastModifiedTimestamp", lastModifiedTimestamp)
				: null;
		temp = creationDateTime != "" ? updateDossierRequestJson.put("creationDateTime", creationDateTime) : null;
		temp = creationDateTime != "" ? updateDossierRequestJson.put("creatorConsumerId", creatorConsumerId) : null;
		temp = lastModifierUserId != "" ? updateDossierRequestJson.put("lastModifierUserId", lastModifierUserId) : null;
		temp = title != "" ? updateDossierRequestJson.put("title", title) : null;
		temp = description != "" ? updateDossierRequestJson.put("description", description) : null;
		temp = sourceLabel != "" ? updateDossierRequestJson.put("sourceLabel", sourceLabel) : null;
		temp = accessType != "" ? updateDossierRequestJson.put("accessType", accessType) : null;
		temp = securityLevel != "" ? updateDossierRequestJson.put("securityLevel", securityLevel) : null;
		temp = dossierName != "" ? updateDossierRequestJson.put("dossierName", dossierName) : null;
		temp = dossierType != "" ? updateDossierRequestJson.put("dossierType", dossierType) : null;
		temp = status != "" ? updateDossierRequestJson.put("status", status) : null;
		temp = relatedEntities != "" ? updateDossierRequestJson.put("relatedEntities", setMultipleInfoIntoArray(relatedEntities))
				: null;
		temp = dossierContexts != "" ? updateDossierRequestJson.put("dossierContexts", setMultipleInfoIntoArray(dossierContexts))
				: null;
		temp = scopes != "" ? updateDossierRequestJson.put("scopes", setMultipleInfoIntoArray(scopes)) : null;
		temp = actionslist != "" ? updateDossierRequestJson.put("actionslist", setMultipleInfoIntoArray(actionslist)) : null;
		temp = retention != "" ? updateDossierRequestJson.put("retention", setObject(retention)) : null;
		temp = rating != "" ? updateDossierRequestJson.put("rating", setObject(rating)) : null;

		/*JSONObject dossierBody = new JSONObject();
		dossierBody.put("dossier", updateDossierRequestJson);
		updateDossierRequestBody = dossierBody.toString()*/;
		updateDossierRequestBody = updateDossierRequestJson.toString();

	}

	public static String getUpdateDossierRequestBody() {
		return updateDossierRequestBody;
	}

	public static List<Map<String, String>> setMultipleInfoIntoArray(String value) {
		String[] eachObject = value.split(";");
		List<Map<String, String>> tripletArray = new ArrayList<Map<String, String>>();
		for (int i = 0; i < eachObject.length; i++) {
			String[] eachKeyVal = eachObject[i].split("-");
			Map<String, String> keyVal = new HashMap<String, String>();

			for (int j = 0; j < eachKeyVal.length; j++) {
				keyVal.put(eachKeyVal[j].substring(0, eachKeyVal[j].indexOf("=")),
						eachKeyVal[j].substring(eachKeyVal[j].indexOf("=") + 1));
			}
			tripletArray.add(keyVal);
		}
		return tripletArray;
	}

	public static Map<String, String> setObject(String tripletInfo) {
		String[] eachTriplet = tripletInfo.split(",");
		Map<String, String> keyVal = new HashMap<String, String>();
		for (int j = 0; j < eachTriplet.length; j++) {
			keyVal.put(eachTriplet[j].substring(0, eachTriplet[j].indexOf("=")),
					eachTriplet[j].substring(eachTriplet[j].indexOf("=") + 1));
		}
		return keyVal;
	}

}
