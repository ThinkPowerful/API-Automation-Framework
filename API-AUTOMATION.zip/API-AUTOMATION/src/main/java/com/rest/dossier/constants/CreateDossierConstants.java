package com.rest.dossier.constants;

public class CreateDossierConstants {

	public static String createDossierOnlyWithDossierName;
	public static String CreateDossierRequestBodyWithAllParameters;
	public static String CreateDossierRequestBodyWithMultipleRelatedEntityInfo;
	

	public static String getCreateDossierOnlyWithDossierName() {
		return createDossierOnlyWithDossierName;
	}

	public static void setCreateDossierOnlyWithDossierName(String dossierName) {
		
		/*CreateDossierConstants.createDossierOnlyWithDossierName = "{\"dossierName\":\"" + dossierName
				+ "\",\"securityClassifier\":\"/RK/workspaces/NL\"}";
		System.out.println(createDossierOnlyWithDossierName);*/
		
		CreateDossierConstants.createDossierOnlyWithDossierName = "{\"dossierName\":\"" + dossierName
				+ "\",\"relatedEntity\": [{\"id\": \"1724\",\"administrationId\": \"2\",\"type\": \"CUSTOMER\"}], \"securityClassifier\": \"/RK/workspaces/NL\"}";
	}
	
	public static void setCreateDossierRequestBodyWithAllParameters(String dossierName, String title,
			String description, String sourceID, String sourceLabel, String relatedEntityAdministrationID,
			String relatedEntityId, String relatedEntityType, String retentionPeriod, String retentionStartDateTime,
			String retentionEndDateTime, String scopeAdministrationID, String scopeType, String scopeValue,
			String securityLevel, String confidentialityRating, String integrityRating, String availabilityRating,
			String securityClassifier, String dossierType, String dossierContextValue, String dossierContextType,
			String dossierContextAdmin) {
		CreateDossierConstants.CreateDossierRequestBodyWithAllParameters = "{\"dossierName\":\"" + dossierName
				+ "\",\"title\":\"" + title + "\",\"description\":\"" + description + "\",\"sourceId\":\"" + sourceID
				+ "\",\"sourceLabel\":\"" + sourceLabel + "\",\"relatedEntity\":[{\"administrationId\":\""
				+ relatedEntityAdministrationID + "\",\"id\":\"" + relatedEntityId + "\",\"type\":\""
				+ relatedEntityType + "\"}],\"retentionPolicyInfo\":{\"retentionPeriod\":\"" + retentionPeriod
				+ "\",\"retentionStartDateTime\":\"" + retentionStartDateTime + "\",\"retentionEndDateTime\":\""
				+ retentionEndDateTime + "\"},\"scope\":[{\"administrationId\":\"" + scopeAdministrationID
				+ "\",\"type\":\"" + scopeType + "\",\"value\":\"" + scopeValue + "\"}],\"securityLevel\":\""
				+ securityLevel + "\",\"rating\":{\"confidentialityRating\":\"" + confidentialityRating
				+ "\",\"integrityRating\":\"" + integrityRating + "\",\"availabilityRating\":\"" + availabilityRating
				+ "\"},\"securityClassifier\":\"" + securityClassifier + "\",\"dossierType\":\"" + dossierType
				+ "\",\"dossierContexts\":[{\"value\":\"" + dossierContextValue + "\",\"type\":\"" + dossierContextType
				+ "\",\"admin\":\"" + dossierContextAdmin + "\"}]}";
	}
	
	public static void setCreateDossierRequestBodyWithMultipleRelatedEntityInfo(String dossierName, String title,
			String description, String sourceID, String sourceLabel, String relatedEntityTriplet, String retentionPeriod, String retentionStartDateTime,
			String retentionEndDateTime, String scopeAdministrationID, String scopeType, String scopeValue,
			String securityLevel, String confidentialityRating, String integrityRating, String availabilityRating,
			String securityClassifier, String dossierType, String dossierContextValue, String dossierContextType,
			String dossierContextAdmin) {
		
		
		if (relatedEntityTriplet.contains(",")) {
			StringBuilder formRelatedEntittyInfo = new StringBuilder();
			String commoTruncated;
			String relatedEntityInfo = relatedEntityTriplet;
			String[] relatedEntitySplitOnCommo = relatedEntityInfo.split(",");
			for (int i = 0; i < relatedEntitySplitOnCommo.length; i++) {
				String[] relatedEntitySplitOnHyphen = relatedEntitySplitOnCommo[i].split("-");
				formRelatedEntittyInfo.append("{\"administrationId\":\""
						+ relatedEntitySplitOnHyphen[0] + "\",\"type\":\"" + relatedEntitySplitOnHyphen[1]
						+ "\",\"id\":\"" + relatedEntitySplitOnHyphen[2] + "\"},");
			}
		commoTruncated = formRelatedEntittyInfo.substring(0, formRelatedEntittyInfo.length() - 1);
		CreateDossierConstants.CreateDossierRequestBodyWithMultipleRelatedEntityInfo = "{\"dossierName\":\"" + dossierName
				+ "\",\"title\":\"" + title + "\",\"description\":\"" + description + "\",\"sourceId\":\"" + sourceID
				+ "\",\"sourceLabel\":\"" + sourceLabel + "\",\"relatedEntity\":["+commoTruncated+"],\"retentionPolicyInfo\":{\"retentionPeriod\":\"" + retentionPeriod
				+ "\",\"retentionStartDateTime\":\"" + retentionStartDateTime + "\",\"retentionEndDateTime\":\""
				+ retentionEndDateTime + "\"},\"scope\":[{\"administrationId\":\"" + scopeAdministrationID
				+ "\",\"type\":\"" + scopeType + "\",\"value\":\"" + scopeValue + "\"}],\"securityLevel\":\""
				+ securityLevel + "\",\"rating\":{\"confidentialityRating\":\"" + confidentialityRating
				+ "\",\"integrityRating\":\"" + integrityRating + "\",\"availabilityRating\":\"" + availabilityRating
				+ "\"},\"securityClassifier\":\"" + securityClassifier + "\",\"dossierType\":\"" + dossierType
				+ "\",\"dossierContexts\":[{\"value\":\"" + dossierContextValue + "\",\"type\":\"" + dossierContextType
				+ "\",\"admin\":\"" + dossierContextAdmin + "\"}]}";
		}
		else {
			String relatedEntityInfo = relatedEntityTriplet;
			String[] relatedEntityInfoSplitValue = relatedEntityInfo.split("-");
			CreateDossierConstants.CreateDossierRequestBodyWithMultipleRelatedEntityInfo="{\"dossierName\":\"" + dossierName
				+ "\",\"title\":\"" + title + "\",\"description\":\"" + description + "\",\"sourceId\":\"" + sourceID
				+ "\",\"sourceLabel\":\"" + sourceLabel + "\",\"relatedEntity\":[{\"administrationId\":\""
				+ relatedEntityInfoSplitValue[0] + "\",\"id\":\"" + relatedEntityInfoSplitValue[2] + "\",\"type\":\""
				+ relatedEntityInfoSplitValue[1] + "\"}],\"retentionPolicyInfo\":{\"retentionPeriod\":\"" + retentionPeriod
				+ "\",\"retentionStartDateTime\":\"" + retentionStartDateTime + "\",\"retentionEndDateTime\":\""
				+ retentionEndDateTime + "\"},\"scope\":[{\"administrationId\":\"" + scopeAdministrationID
				+ "\",\"type\":\"" + scopeType + "\",\"value\":\"" + scopeValue + "\"}],\"securityLevel\":\""
				+ securityLevel + "\",\"rating\":{\"confidentialityRating\":\"" + confidentialityRating
				+ "\",\"integrityRating\":\"" + integrityRating + "\",\"availabilityRating\":\"" + availabilityRating
				+ "\"},\"securityClassifier\":\"" + securityClassifier + "\",\"dossierType\":\"" + dossierType
				+ "\",\"dossierContexts\":[{\"value\":\"" + dossierContextValue + "\",\"type\":\"" + dossierContextType
				+ "\",\"admin\":\"" + dossierContextAdmin + "\"}]}";
		}
	}
	

	public static String getCreateDossierRequestBodyWithAllParameters()
	{
		return CreateDossierRequestBodyWithAllParameters;
	}
	
	public static String getCreateDossierRequestBodyWithMultipleRelatedEntityInfo()
	{
		return CreateDossierRequestBodyWithMultipleRelatedEntityInfo;
	}
	
	

}
