package com.rest.dossier.constants;

public class AddRelatedEntityConstants {

	public static String addRelatedEntityRequestBodyWithMultipleRelatedEntityInfo;

	public static void setAddRelatedEntityRequestBodyWithMultipleRelatedEntityInfo(String relatedEntityTriplet) {

		if (!relatedEntityTriplet.equalsIgnoreCase("") && relatedEntityTriplet.contains(",")) {
			StringBuilder formRelatedEntittyInfo = new StringBuilder();
			String commoTruncated;
			String relatedEntityInfo = relatedEntityTriplet;
			String[] relatedEntitySplitOnCommo = relatedEntityInfo.split(",");
			for (int i = 0; i < relatedEntitySplitOnCommo.length; i++) {
				String[] relatedEntitySplitOnHyphen = relatedEntitySplitOnCommo[i].split("-");
				formRelatedEntittyInfo.append("{\"administrationId\":\"" + relatedEntitySplitOnHyphen[0]
						+ "\",\"type\":\"" + relatedEntitySplitOnHyphen[1] + "\",\"id\":\""
						+ relatedEntitySplitOnHyphen[2] + "\"},");
			}
			commoTruncated = formRelatedEntittyInfo.substring(0, formRelatedEntittyInfo.length() - 1);
			AddRelatedEntityConstants.addRelatedEntityRequestBodyWithMultipleRelatedEntityInfo = "{\"relatedEntities\":["
					+ commoTruncated + "]}";
		} else if (!relatedEntityTriplet.equalsIgnoreCase("")) {
			String relatedEntityInfo = relatedEntityTriplet;
			String[] relatedEntityInfoSplitValue = relatedEntityInfo.split("-");
			AddRelatedEntityConstants.addRelatedEntityRequestBodyWithMultipleRelatedEntityInfo = "{\"relatedEntities\":[{\"administrationId\":\""
					+ relatedEntityInfoSplitValue[0] + "\",\"id\":\"" + relatedEntityInfoSplitValue[2]
					+ "\",\"type\":\"" + relatedEntityInfoSplitValue[1] + "\"}]}";
		} else {
			AddRelatedEntityConstants.addRelatedEntityRequestBodyWithMultipleRelatedEntityInfo = "{\"relatedEntities\":[]}";
		}
	}

	public static String getAddRelatedEntityRequestBodyWithMultipleRelatedEntityInfo() {
		return addRelatedEntityRequestBodyWithMultipleRelatedEntityInfo;
	}

}
