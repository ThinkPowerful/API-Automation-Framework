package com.rest.documentservice;

import static io.restassured.RestAssured.given;
import java.io.IOException;

import com.rest.baseservice.BaseOperation;
import com.rest.document.constants.AddRelatedEntityConstants;
import io.restassured.response.Response;

public class AddRelatedEntities extends BaseOperation {

	public AddRelatedEntities() throws IOException {
		super();
	}

	public Response relatedEntityAdditionWithConsumerID(String documentId, String relatedEntityTriplet)
			throws InterruptedException {

		AddRelatedEntityConstants.setAddRelatedEntityRequestBodyWithMultipleRelatedEntityInfo(relatedEntityTriplet);
		String body = AddRelatedEntityConstants.getAddRelatedEntityRequestBodyWithMultipleRelatedEntityInfo();
		Response res =given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit").keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header("Content-Type", prop.get("Content-Type"))
				.header("Consumer-Id", prop.get("CONSUMERID")).body(body).when()
				.post(prop.getProperty("BASEURI") + "/rest/api/v2/documents/" + documentId + "/relatedentitiesaddition");
		System.out.println(res.getStatusCode());
		return res;

	}

	public Response relatedEntityAdditionWithoutConsumerID(String documentId, String relatedEntityTriplet)
			throws InterruptedException {
		AddRelatedEntityConstants.setAddRelatedEntityRequestBodyWithMultipleRelatedEntityInfo(relatedEntityTriplet);
		String body = AddRelatedEntityConstants.getAddRelatedEntityRequestBodyWithMultipleRelatedEntityInfo();
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit").keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header("Content-Type", prop.get("Content-Type")).body(body).when()
				.post(prop.getProperty("BASEURI") + "/rest/api/v2/documents/" + documentId + "/relatedentitiesaddition");
		return res;
	}

}