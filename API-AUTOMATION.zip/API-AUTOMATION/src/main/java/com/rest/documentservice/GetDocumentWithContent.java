package com.rest.documentservice;

import static io.restassured.RestAssured.given;

import java.io.IOException;

import com.rest.baseservice.BaseOperation;
import com.rest.document.constants.GetDocumentWithContentConstants;

import io.restassured.response.Response;

public class GetDocumentWithContent extends BaseOperation {

	public GetDocumentWithContent() throws IOException {
		super();
	}

	public Response downloadMultipleDocumentsWithContent(String documentIDs) {
		GetDocumentWithContentConstants.setDocumentIDs(documentIDs);
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit")
				.keyStore("certs/certificate_pkey_new.jks", "esb-et-test")
				.header("Content-Type", prop.get("Content-Type")).cookie("SMSESSION", prop.getProperty("SESSION"))
				.body(GetDocumentWithContentConstants.getDocumentIDs()).when()
				.post(prop.getProperty("BASEURI") + "/rest/api/v2/documentsretrieval");
		return res;
	}

	public Response downloadOneOrMultipleDocumentsWithContent(String documentIDs, String accept) {
		GetDocumentWithContentConstants.setDocumentIDs(documentIDs);
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit")
				.keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header("Accept", accept)
				.header("Content-Type", prop.get("Content-Type")).cookie("SMSESSION", prop.getProperty("SESSION"))
				.body(GetDocumentWithContentConstants.getDocumentIDs()).when()
				.post(prop.getProperty("BASEURI") + "/rest/api/v2/documentsretrieval");
		return res;
	}

	public Response downloadMultipleDocumentsWithContentWithoutConsumerID(String documentIDs) {
		GetDocumentWithContentConstants.setDocumentIDs(documentIDs);
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit")
				.keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header("Accept", "application/zip")
				.header("Content-Type", prop.get("Content-Type")).body(GetDocumentWithContentConstants.getDocumentIDs())
				.when().post(prop.getProperty("BASEURI") + "/rest/api/v2/documentsretrieval");
		return res;
	}

	public Response downloadOneOrMultipleDocumentsWithContentWithConsumerID(String documentIDs, String accept) {
		GetDocumentWithContentConstants.setDocumentIDs(documentIDs);
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit")
				.keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header("Accept", accept)
				.header("Content-Type", prop.get("Content-Type")).header("consumer-id", prop.getProperty("CONSUMERID"))
				.body(GetDocumentWithContentConstants.getDocumentIDs()).when()
				.post(prop.getProperty("BASEURI") + "/rest/api/v2/documentsretrieval");
		return res;
	}

}
