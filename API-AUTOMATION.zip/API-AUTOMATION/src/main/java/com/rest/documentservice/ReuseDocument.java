package com.rest.documentservice;

import static io.restassured.RestAssured.given;

import java.io.IOException;

import com.rest.baseservice.BaseOperation;
import com.rest.document.constants.ReuseDocumentConstants;
import io.restassured.response.Response;

public class ReuseDocument extends BaseOperation{

	public ReuseDocument() throws IOException {
		super();
	}

	public Response reuseDocumentInsideDossier(String dossierID, String documentID)
	{
		ReuseDocumentConstants.setReuseDocumentRequestBody(dossierID, documentID);
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit").keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header("Content-Type", prop.get("Content-Type")).cookie("SMSESSION", prop.getProperty("SESSION")).body(ReuseDocumentConstants.getReuseDocumentRequestBody()).
					when().post(prop.getProperty("BASEURI")+"/rest/api/v2/documents/reuse");
		return res;
	}
	
}
