package com.rest.documentservice;

import static io.restassured.RestAssured.given;

import java.io.IOException;

import com.rest.baseservice.BaseOperation;
import com.rest.document.constants.UpdateLifecycleStatusConstants;

import io.restassured.response.Response;

public class UpdateLifecycleStatus extends BaseOperation {

	public UpdateLifecycleStatus() throws IOException {
		super();
	}

	public Response updateLifecycleStatus(String documentId, String status)
	{
		UpdateLifecycleStatusConstants.setUpdateLifecycleStatusRequestBodu(documentId, status);
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit").keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header("Content-Type", prop.get("Content-Type")).cookie("SMSESSION", prop.getProperty("SESSION")).body(UpdateLifecycleStatusConstants.getUpdateLifecycleStatusRequestBody()).
					when().post(prop.getProperty("BASEURI")+"/rest/api/v1/documents/" +documentId+ "/status");
		return res;
	}
}
