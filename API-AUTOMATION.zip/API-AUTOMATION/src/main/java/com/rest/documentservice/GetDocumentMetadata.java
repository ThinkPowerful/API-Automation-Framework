package com.rest.documentservice;

import static io.restassured.RestAssured.given;

import java.io.IOException;

import com.rest.baseservice.BaseOperation;

import io.restassured.response.Response;

/**
 * @author C46630
 *
 */
public class GetDocumentMetadata extends BaseOperation {
  private static final String CONTENT_TYPE = "Content-Type";

  public GetDocumentMetadata() throws IOException {
    super();
  }

  /**
   * 
   * @param dossierId
   * @return
   */
  public Response getDocumentMetaData(String documentId) {



    return given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit").keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header(CONTENT_TYPE, prop.get(CONTENT_TYPE)).cookie("SMSESSION", prop.getProperty("SESSION")).when()
        .get(prop.getProperty("BASEURI") + "/rest/api/v2/documents/drm_" + documentId + "/metadata");
  }

  public Response getDocumentMetaDataWithoutConsumerID(String documentId) {

    return given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit").keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header(CONTENT_TYPE, prop.get(CONTENT_TYPE)).when()
        .get(prop.getProperty("BASEURI") + "/rest/api/v2/documents/drm_" + documentId + "/metadata");

  }
}
