package com.rest.documentservice;

import static io.restassured.RestAssured.given;

import java.io.IOException;

import com.rest.baseservice.BaseOperation;
import com.rest.document.constants.UpdateDocumentConstants;

import io.restassured.response.Response;

public class UpdateDocument extends BaseOperation {

	public UpdateDocument() throws IOException {
		super();
	}

	public Response updateDocumentWithAllParameters(String documentId, String sourceId, String title,
			String description, String sourceLabel, String accessType, String securityLevel, String documentName,
			String source, String status, String relatedEntity, String scopeInfo,
			String actionslist, String retention, String rating, String legalHoldStatus, String documentType, 
			String scanStatus, String validityStatus, String contentSize, String contentType, 
			String docValidityStatus, String annotationInfoAvailable, String validFromDate, String validToDate, 
			String eventDate, String versionLabel, String additionalAttribute, String authors) throws InterruptedException {

		UpdateDocumentConstants.setUpdateDocumentRequestBody(documentId, sourceId, title, description, sourceLabel, accessType, securityLevel, documentName, source, status, relatedEntity, scopeInfo, actionslist, retention, rating, legalHoldStatus, documentType, scanStatus, validityStatus, contentSize, contentType, docValidityStatus, annotationInfoAvailable, validFromDate, validToDate, versionLabel, additionalAttribute, authors);
		String body = UpdateDocumentConstants.getUpdateDocumentRequestBody();
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit").keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header("Content-Type", prop.get("Content-Type"))
				.cookie("SMSESSION", prop.getProperty("SESSION")).body(body).when()
				.put(prop.getProperty("BASEURI") + "/rest/api/v2/documents/" + documentId);
		Thread.sleep(4000);
		return res;
	}
}
