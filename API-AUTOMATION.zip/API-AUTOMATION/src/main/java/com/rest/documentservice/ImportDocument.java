package com.rest.documentservice;

import static io.restassured.RestAssured.given;

import java.io.File;
import java.io.IOException;

import com.rest.baseservice.BaseOperation;
import com.rest.document.constants.ImportDocumentConstants;

import io.restassured.response.Response;

public class ImportDocument extends BaseOperation {

	public ImportDocument() throws IOException {
		super();
	}

	public Response importDocument(String jsonFilePath, String contentFilePath) {
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit").keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header("Content-Type", "multipart/form-data")
				.cookie("SMSESSION", prop.getProperty("SESSION"))
				.multiPart("documentRequest", new File(jsonFilePath), "text/json")
				.multiPart("content", new File(contentFilePath), "text/html").when()
				.post(prop.getProperty("BASEURI") + "/rest/api/v2/documents");
		return res;
	}

	public Response importDocumentDynamicRequest(String documentName, String relatedEntity, String documentType,
			String scanStatus, String sourceCreationDateTime, String validFromDate, String validToDate,
			String documentDossierReference,String securityClassifier,boolean addToDossier, String jsonFilePath, String contentFilePath) throws IOException {
		ImportDocumentConstants.setImportDocumentRequestBody(documentName, relatedEntity, documentType, scanStatus,
				sourceCreationDateTime, validFromDate, validToDate, documentDossierReference,securityClassifier, addToDossier);
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit").keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header("Content-Type", "multipart/form-data")
				.cookie("SMSESSION", prop.getProperty("SESSION"))
				.multiPart("documentRequest", new File(jsonFilePath), "text/json")
				.multiPart("content", new File(contentFilePath), "text/html").when()
				.post(prop.getProperty("BASEURI") + "/rest/api/v2/documents");
		return res;
	}

	public Response importDocumentDynamicRequestWithoutConsumerID(String documentName, String relatedEntity,
			String documentType, String scanStatus, String sourceCreationDateTime, String validFromDate,
			String validToDate, String documentDossierReference, String securityClassifier,boolean addToDossier, String jsonFilePath, String contentFilePath)
			throws IOException {
		ImportDocumentConstants.setImportDocumentRequestBody(documentName, relatedEntity, documentType, scanStatus,
				sourceCreationDateTime, validFromDate, validToDate, documentDossierReference, securityClassifier,addToDossier);
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit").keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header("Content-Type", "multipart/form-data")
				.multiPart("documentRequest", new File(jsonFilePath), "text/json")
				.multiPart("content", new File(contentFilePath), "text/html").when()
				.post(prop.getProperty("BASEURI") + "/rest/api/v2/documents");
		return res;
	}

}
