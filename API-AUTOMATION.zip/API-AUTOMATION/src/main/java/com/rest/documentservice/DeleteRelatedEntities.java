package com.rest.documentservice;

import static io.restassured.RestAssured.given;
import java.io.IOException;

import com.rest.baseservice.BaseOperation;
import com.rest.document.constants.DeleteRelatedEntityConstants;
import io.restassured.response.Response;

public class DeleteRelatedEntities extends BaseOperation {

	public DeleteRelatedEntities() throws IOException {
		super();
	}

	public Response relatedEntityDeletionWithConsumerID(String documentId, String relatedEntityTriplet)
			throws InterruptedException {

		DeleteRelatedEntityConstants
				.setDeleteRelatedEntityRequestBodyWithMultipleRelatedEntityInfo(relatedEntityTriplet);
		String body = DeleteRelatedEntityConstants.getDeleteRelatedEntityRequestBodyWithMultipleRelatedEntityInfo();
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit").keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header("Content-Type", prop.get("Content-Type"))
				.header("Consumer-Id", prop.get("CONSUMERID")).body(body).when()
				.post(prop.getProperty("BASEURI") + "/rest/api/v2/documents/" + documentId + "/relatedentitiesdeletion");
		return res;

	}

	public Response relatedEntityDeletionWithoutConsumerID(String documentId, String relatedEntityTriplet) {
		DeleteRelatedEntityConstants
				.setDeleteRelatedEntityRequestBodyWithMultipleRelatedEntityInfo(relatedEntityTriplet);
		String body = DeleteRelatedEntityConstants.getDeleteRelatedEntityRequestBodyWithMultipleRelatedEntityInfo();
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit").keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header("Content-Type", prop.get("Content-Type")).body(body).when()
				.post(prop.getProperty("BASEURI") + "/rest/api/v2/documents/" + documentId + "/relatedentitiesdeletion");
		return res;
	}

}
