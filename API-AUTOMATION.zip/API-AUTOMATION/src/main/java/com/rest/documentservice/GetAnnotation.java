package com.rest.documentservice;

import static io.restassured.RestAssured.given;

import java.io.IOException;

import com.rest.baseservice.BaseOperation;

import io.restassured.response.Response;

public class GetAnnotation extends BaseOperation{

	public GetAnnotation() throws IOException {
		super();
	}

	public Response getAnnotationForDocuments(String documentID)
	{
		Response res = given().relaxedHTTPSValidation().trustStore("certs/trustore.jks", "changeit").keyStore("certs/certificate_pkey_new.jks", "esb-et-test").header("Content-Type", prop.get("Content-Type")).cookie("SMSESSION", prop.getProperty("SESSION")).
					when().get(prop.getProperty("BASEURI")+"/rest/api/v2/documents/drm:"+documentID+"/annotations");
		return res;
	}
	
}
