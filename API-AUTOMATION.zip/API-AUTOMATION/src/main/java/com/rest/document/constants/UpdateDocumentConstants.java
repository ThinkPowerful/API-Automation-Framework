package com.rest.document.constants;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

public class UpdateDocumentConstants {

	public static String updateDocumentRequestBody;

	public static void setUpdateDocumentRequestBody(String documentId, String sourceId, String title,
			String description, String sourceLabel, String accessType, String securityLevel, String documentName,
			String source, String status, String relatedEntity, String scopeInfo, String actionslist, String retention,
			String rating, String legalHoldStatus, String documentType, String scanStatus, String validityStatus,
			String contentSize, String contentType, String docValidityStatus, String annotationInfoAvailable,
			String validFromDate, String validToDate, String versionLabel, String additionalAttribute,
			String authors) {

		JSONObject temp;
		JSONObject updateDocumentRequestJson = new JSONObject();
		temp = sourceId != "" ? updateDocumentRequestJson.put("sourceId", sourceId) : null;
		temp = title != "" ? updateDocumentRequestJson.put("title", title) : null;
		temp = description != "" ? updateDocumentRequestJson.put("description", description) : null;
		temp = sourceLabel != "" ? updateDocumentRequestJson.put("sourceLabel", sourceLabel) : null;
		temp = accessType != "" ? updateDocumentRequestJson.put("accessType", accessType) : null;
		temp = securityLevel != "" ? updateDocumentRequestJson.put("securityLevel", securityLevel) : null;
		temp = documentName != "" ? updateDocumentRequestJson.put("documentName", documentName) : null;
		temp = source != "" ? updateDocumentRequestJson.put("source", source) : null;
		temp = scanStatus != "" ? updateDocumentRequestJson.put("scanStatus", scanStatus) : null;
		temp = validityStatus != "" ? updateDocumentRequestJson.put("validityStatus", validityStatus) : null;
		temp = contentSize != "" ? updateDocumentRequestJson.put("contentSize", contentSize) : null;
		temp = contentType != "" ? updateDocumentRequestJson.put("contentType", contentType) : null;
		temp = docValidityStatus != "" ? updateDocumentRequestJson.put("docValidityStatus", docValidityStatus) : null;
		temp = annotationInfoAvailable != ""
				? updateDocumentRequestJson.put("annotationInfoAvailable", annotationInfoAvailable)
				: null;
		temp = validFromDate != "" ? updateDocumentRequestJson.put("validFromDate", validFromDate) : null;
		temp = validToDate != "" ? updateDocumentRequestJson.put("validToDate", validToDate) : null;
		temp = versionLabel != "" ? updateDocumentRequestJson.put("versionLabel", versionLabel) : null;
		temp = relatedEntity != ""
				? updateDocumentRequestJson.put("relatedEntity", setMultipleInfoIntoArray(relatedEntity))
				: null;
		temp = additionalAttribute != ""
				? updateDocumentRequestJson.put("additionalAttribute", setAdditionalAtribute(additionalAttribute))
				: null;
		temp = documentType != "" ? updateDocumentRequestJson.put("documentType", setObject(documentType, ",")) : null;
		temp = scopeInfo != "" ? updateDocumentRequestJson.put("scope", setMultipleInfoIntoArray(scopeInfo)) : null;
		temp = legalHoldStatus != "" ? updateDocumentRequestJson.put("legalHoldStatus", setObject(legalHoldStatus, ","))
				: null;
		temp = actionslist != "" ? updateDocumentRequestJson.put("actionslist", setMultipleInfoIntoArray(actionslist))
				: null;
		temp = retention != "" ? updateDocumentRequestJson.put("retention", setObject(retention, ",")) : null;
		temp = rating != "" ? updateDocumentRequestJson.put("rating", setObject(rating, ",")) : null;
		temp = authors != "" ? updateDocumentRequestJson.put("authors", setArray(authors)) : null;
		updateDocumentRequestBody = updateDocumentRequestJson.toString();

	}

	public static JSONArray setAdditionalAtribute(String additionalAttribute) {
		JSONArray additionalAttributeArray = new JSONArray();
		String[] allAdditionalAttribute = additionalAttribute.split(";");
		for (int i = 0; i < allAdditionalAttribute.length; i++) {
			String[] eachAdditionalAttribute = allAdditionalAttribute[i].split("-");
			JSONObject keyVal = new JSONObject();
			keyVal.put("key", eachAdditionalAttribute[0]);
			keyVal.put("value", eachAdditionalAttribute[1].split(","));
			additionalAttributeArray.put(keyVal);
		}
		return additionalAttributeArray;

	}

	public static String getUpdateDocumentRequestBody() {
		return updateDocumentRequestBody;
	}

	public static List<Map<String, String>> setMultipleInfoIntoArray(String value) {
		String[] eachObject = value.split(";");
		List<Map<String, String>> tripletArray = new ArrayList<Map<String, String>>();
		for (int i = 0; i < eachObject.length; i++) {
			tripletArray.add(setObject(eachObject[i], "-"));
		}
		return tripletArray;
	}

	public static Map<String, String> setObject(String tripletInfo, String regex) {
		String[] eachTriplet = tripletInfo.split(regex);
		Map<String, String> keyVal = new HashMap<String, String>();
		for (int j = 0; j < eachTriplet.length; j++) {
			keyVal.put(eachTriplet[j].substring(0, eachTriplet[j].indexOf("=")),
					eachTriplet[j].substring(eachTriplet[j].indexOf("=") + 1));
		}
		return keyVal;
	}

	public static String[] setArray(String values) {
		return values.split(";");
	}

}
