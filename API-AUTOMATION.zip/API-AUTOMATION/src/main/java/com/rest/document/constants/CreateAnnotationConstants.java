package com.rest.document.constants;



public class CreateAnnotationConstants {
	public static String annotation;

	public static void setAnnotation(String annotationText) {

		CreateAnnotationConstants.annotation = "{\"annotation\": {\"text\": \"" + annotationText + "\"}}";

	}

	public static String getAnnotation() {
		return annotation;
	}

}
