package com.rest.document.constants;

import org.json.JSONObject;

public class UpdateLifecycleStatusConstants {

	static String updateLifecycleStatusRequest;

	public static void setUpdateLifecycleStatusRequestBodu(String documentId, String status) {
		JSONObject temp;
		JSONObject requestJson = new JSONObject();
		temp = status != "" ? requestJson.put("status", status) : null;

		JSONObject updateLifecycleStatusRequestBody = new JSONObject();
		updateLifecycleStatusRequestBody.put("document", requestJson);
		UpdateLifecycleStatusConstants.updateLifecycleStatusRequest = updateLifecycleStatusRequestBody.toString();
	}

	public static String getUpdateLifecycleStatusRequestBody() {
		return updateLifecycleStatusRequest;
	}
}
