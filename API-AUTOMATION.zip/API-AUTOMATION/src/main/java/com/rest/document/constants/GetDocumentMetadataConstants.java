package com.rest.document.constants;

public class GetDocumentMetadataConstants {

}
