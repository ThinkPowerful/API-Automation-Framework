package com.rest.document.constants;

public class GetDocumentWithContentConstants {

	public static String documentIDs;

	public static String getDocumentIDs() {
		return documentIDs;
	}

	public static void setDocumentIDs(String documentIDs) {
		
		if(documentIDs.isEmpty())
		{
			GetDocumentWithContentConstants.documentIDs = "{\"documentIds\":[ ]}";
		}
		else if(!documentIDs.contains(","))
		{
			String enrichedDocumentIDs = null;
			if(enrichedDocumentIDs==null && documentIDs.startsWith("0")){
				enrichedDocumentIDs="\"earchive_"+documentIDs+"\",";
			}
			else if(enrichedDocumentIDs==null && documentIDs.startsWith("8"))
			{
				enrichedDocumentIDs="\"drm_"+documentIDs+"\",";
			}
			if(enrichedDocumentIDs.endsWith(",")){
				enrichedDocumentIDs = enrichedDocumentIDs.substring(0, enrichedDocumentIDs.length()-1);
			}
			GetDocumentWithContentConstants.documentIDs = "{\"documentIds\":["+enrichedDocumentIDs+"]}";
		}
		else
		{
			String [] arrOfDocumentIDs = documentIDs.split(","); 
			String enrichedDocumentIDs = null;
			for(String documentID:arrOfDocumentIDs){   
				if(enrichedDocumentIDs==null && documentID.startsWith("0")){
					enrichedDocumentIDs="\"earchive_"+documentID+"\",";
				}
				else if(enrichedDocumentIDs==null && documentID.startsWith("8"))
				{
					enrichedDocumentIDs="\"drm_"+documentID+"\",";
				}
				else if(documentID.startsWith("0")){
					enrichedDocumentIDs=enrichedDocumentIDs+"\"earchive_"+documentID+"\",";
				}
				else if(documentID.startsWith("8"))
				{
					enrichedDocumentIDs=enrichedDocumentIDs+"\"drm_"+documentID+"\",";
				}
			}
			if(enrichedDocumentIDs.endsWith(",")){
				enrichedDocumentIDs = enrichedDocumentIDs.substring(0, enrichedDocumentIDs.length()-1);
			}
			GetDocumentWithContentConstants.documentIDs = "{\"documentIds\":["+enrichedDocumentIDs+"]}";
		}
		
	}
	
}
