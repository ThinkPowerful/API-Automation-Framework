package com.rest.document.constants;

import org.json.JSONObject;

public class MergedPdfDocumentContentConstants {

	static String mergePdfRequestBody;

	public static void setMergedPdfDocumentContentRequestBody(String documentIDs) {
		String [] documentIdArray = documentIDs.split(",");
		JSONObject temp;
		JSONObject requestJson = new JSONObject();
		temp = documentIDs != "" ? requestJson.put("documentId", documentIdArray) : null;
		
		JSONObject mergePdfRequestBody = new JSONObject();
		mergePdfRequestBody.put("documentIds", requestJson);
		MergedPdfDocumentContentConstants.mergePdfRequestBody = mergePdfRequestBody.toString();
	}

	public static String getMergedPdfDocumentContentRequestBody() {
		return mergePdfRequestBody;
	}
}
