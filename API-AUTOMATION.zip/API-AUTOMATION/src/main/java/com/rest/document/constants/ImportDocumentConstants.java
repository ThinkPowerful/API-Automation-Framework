package com.rest.document.constants;

import java.io.FileOutputStream;
import java.io.IOException;

import org.json.JSONObject;

import com.rest.baseconstant.BaseConstants;

public class ImportDocumentConstants extends BaseConstants {

	public static String importDocumentRequestBody;
	public static FileOutputStream writeToJsonFile;

	public static void setImportDocumentRequestBody(String documentName, String relatedEntity, String documentType,
			String scanStatus, String sourceCreationDateTime, String validFromDate, String validToDate,String documentDossierReference, String securityClassifier,boolean addToDossier)
			throws IOException {
		JSONObject temp,temp1;
		JSONObject importDocument = new JSONObject();
		temp = documentName != "" ? importDocument.put("documentName", documentName) : null;
		temp = relatedEntity != "" ? importDocument.put("relatedEntity", setMultipleInfoIntoArray(relatedEntity))
				: null;
		temp = documentType != "" ? importDocument.put("documentType", setObject(documentType)) : null;
		temp = scanStatus != "" ? importDocument.put("scanStatus", scanStatus) : null;
		temp = sourceCreationDateTime != "" ? importDocument.put("sourceCreationDateTime", sourceCreationDateTime)
				: null;
		temp = validFromDate != "" ? importDocument.put("validFromDate", validFromDate) : null;
		temp = validToDate != "" ? importDocument.put("validToDate", validToDate) : null;
		temp = securityClassifier != ""? importDocument.put("securityClassifier", securityClassifier) : null;
		JSONObject documentMetadataBody = new JSONObject();
		documentMetadataBody.put("documentMetadata", importDocument);
		temp1 = documentDossierReference != "" ? documentMetadataBody.put("documentDossierReference", setObject(documentDossierReference)) : null;
		documentMetadataBody.put("addToDossier", addToDossier);
		importDocumentRequestBody = documentMetadataBody.toString();
		writeToJsonFile = new FileOutputStream(
				System.getProperty("user.dir") + "/JsonFiles/" + "ImportDocumentDynamic.json");
		byte[] strToBytes = importDocumentRequestBody.getBytes();
		writeToJsonFile.write(strToBytes);
	}

	public static String getImportDocumentRequestBody() {
		return importDocumentRequestBody;
	}

}
