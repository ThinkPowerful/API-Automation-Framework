package com.rest.document.constants;

import org.json.JSONObject;

public class ReuseDocumentConstants {

	static String reuseDocumentRequestBody;

	public static void setReuseDocumentRequestBody(String dossierID, String documentID) {
		JSONObject temp;
		JSONObject requestJson = new JSONObject();
		temp = dossierID != "" ? requestJson.put("dossierId", dossierID) : null;
		temp = documentID != "" ? requestJson.put("documentId", documentID) : null;

		JSONObject resuseDocumentRequestBody = new JSONObject();
		resuseDocumentRequestBody.put("reuseRequest", requestJson);
		ReuseDocumentConstants.reuseDocumentRequestBody = resuseDocumentRequestBody.toString();
	}

	public static String getReuseDocumentRequestBody() {
		return reuseDocumentRequestBody;
	}
}
